package com.dicendo

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp

// Which input field is currently active.
enum class Field { Rolls, Directions, Order }
enum class OrderKbd { K1, K2 }

// Spec symbols
const val BACKSPACE_SYMBOL = "\u232B" // U+232B
const val CLEAR_SYMBOL = "\uD83D\uDDD1" // U+1F5D1
const val CLEAR_ADD_SYMBOL = "+\uD83D\uDDD1" // "+" + U+1F5D1
const val SWITCH_SYMBOL = "\uD83D\uDD01" // U+1F501

// Spec limits
const val MAX_FIELD_LEN = 1024

// Standard keypad font size baseline (sp)
const val STANDARD_KEY_FONT_SP = 16

// Layout constants
val KEY_H: Dp = 48.dp
val BREAK_H: Dp = 3.dp
