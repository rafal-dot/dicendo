package com.dicendo

import java.math.BigInteger

/**
 * Tiny wrapper for BigInteger to keep call sites readable.
 */
data class BigInt(val v: BigInteger) {
    companion object {
        fun ofLong(x: Long): BigInt = BigInt(BigInteger.valueOf(x))
        fun ofInt(x: Int): BigInt = BigInt(BigInteger.valueOf(x.toLong()))
        fun ofBigInteger(x: BigInteger): BigInt = BigInt(x)
    }

    fun addInt(x: Int): BigInt = BigInt(v.add(BigInteger.valueOf(x.toLong())))
    fun multiplyInt(x: Int): BigInt = BigInt(v.multiply(BigInteger.valueOf(x.toLong())))

    /** @return Pair(quotient, remainder) */
    fun divRem(base: Int): Pair<BigInt, Int> {
        val b = BigInteger.valueOf(base.toLong())
        val qr = v.divideAndRemainder(b)
        return Pair(BigInt(qr[0]), qr[1].toInt())
    }

    /** @return Pair(quotient, remainder) */
    fun divRemBig(base: BigInteger): Pair<BigInt, BigInteger> {
        val qr = v.divideAndRemainder(base)
        return Pair(BigInt(qr[0]), qr[1])
    }
}
