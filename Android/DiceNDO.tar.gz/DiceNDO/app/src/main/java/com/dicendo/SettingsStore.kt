package com.dicendo

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.dataStore by preferencesDataStore(name = "dicendo_settings")

object SettingsStore {
    private val KEY_ALPHABET_ID: Preferences.Key<Int> = intPreferencesKey("alphabet_id")
    private val KEY_NUMERIC_N: Preferences.Key<String> = stringPreferencesKey("numeric_n")
    private val KEY_RECENT_PASSWORDS_ENC: Preferences.Key<String> = stringPreferencesKey("recent_passwords_enc")
    private val KEY_RECENT_PASSWORDS_REV: Preferences.Key<Int> = intPreferencesKey("recent_passwords_rev")
    private val KEY_SAVE_PASSWORD_BEFORE_CLEAR: Preferences.Key<Boolean> = booleanPreferencesKey("save_password_before_clear")

    private const val DEFAULT_NUMERIC_N: String = "100"
    private const val DEFAULT_RECENT_PASSWORDS: String = ""
    const val MAX_RECENT_PASSWORDS: Int = 254
    private const val RECENT_PASSWORDS_FILE_NAME: String = "recent_passwords.enc"
    private const val KEYSTORE_ALIAS: String = "dicendo_recent_passwords_aes"
    private const val ANDROID_KEYSTORE: String = "AndroidKeyStore"
    private const val CIPHER_TRANSFORMATION: String = "AES/GCM/NoPadding"
    private const val GCM_TAG_SIZE_BITS: Int = 128

    fun alphabetIdFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { prefs -> prefs[KEY_ALPHABET_ID] ?: Alphabets.DEFAULT_ID }

    fun numericNFlow(context: Context): Flow<String> =
        context.dataStore.data.map { prefs -> prefs[KEY_NUMERIC_N] ?: DEFAULT_NUMERIC_N }

    fun recentPasswordsFlow(context: Context): Flow<List<String>> =
        context.dataStore.data.map { prefs ->
            // Trigger re-read when list is updated.
            prefs[KEY_RECENT_PASSWORDS_REV] ?: 0

            val fromEncryptedFile = readRecentPasswordsFromEncryptedFile(context)
            if (fromEncryptedFile != null) {
                decodeRecentPasswords(fromEncryptedFile)
            } else {
                decodeEncryptedLegacyRecentPasswords(prefs)
            }
        }.flowOn(Dispatchers.IO)

    fun savePasswordBeforeClearFlow(context: Context): Flow<Boolean> =
        context.dataStore.data.map { prefs -> prefs[KEY_SAVE_PASSWORD_BEFORE_CLEAR] ?: false }

    suspend fun setAlphabetId(context: Context, id: Int) {
        context.dataStore.edit { prefs -> prefs[KEY_ALPHABET_ID] = id }
    }

    suspend fun setNumericN(context: Context, n: String) {
        context.dataStore.edit { prefs -> prefs[KEY_NUMERIC_N] = n }
    }

    suspend fun setRecentPasswords(context: Context, passwords: List<String>) {
        val normalized = normalizeRecentPasswords(passwords)
        val writeOk = withContext(Dispatchers.IO) {
            writeRecentPasswordsToEncryptedFile(context, encodeRecentPasswords(normalized))
        }
        if (!writeOk) return
        context.dataStore.edit { prefs ->
            val rev = prefs[KEY_RECENT_PASSWORDS_REV] ?: 0
            prefs[KEY_RECENT_PASSWORDS_REV] = rev + 1
            prefs.remove(KEY_RECENT_PASSWORDS_ENC)
        }
    }

    suspend fun setSavePasswordBeforeClear(context: Context, enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[KEY_SAVE_PASSWORD_BEFORE_CLEAR] = enabled }
    }

    private fun encodeRecentPasswords(passwords: List<String>): String = passwords.joinToString("\n")

    private fun normalizeRecentPasswords(passwords: List<String>): List<String> =
        passwords
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(MAX_RECENT_PASSWORDS)

    private fun decodeRecentPasswords(value: String): List<String> {
        if (value.isBlank()) return emptyList()
        return normalizeRecentPasswords(value.split('\n'))
    }

    private fun decodeEncryptedLegacyRecentPasswords(prefs: Preferences): List<String> {
        val encryptedLegacy = prefs[KEY_RECENT_PASSWORDS_ENC]
        if (encryptedLegacy.isNullOrBlank()) return emptyList()
        val decrypted = runCatching { decryptWithKeystore(encryptedLegacy) }.getOrNull()
        return decodeRecentPasswords(decrypted ?: DEFAULT_RECENT_PASSWORDS)
    }

    private fun readRecentPasswordsFromEncryptedFile(context: Context): String? {
        val file = recentPasswordsFile(context)
        if (!file.exists()) return null
        return runCatching {
            encryptedFile(context, file).openFileInput().use { stream ->
                String(stream.readBytes(), Charsets.UTF_8)
            }
        }.getOrNull()
    }

    private fun writeRecentPasswordsToEncryptedFile(context: Context, value: String): Boolean {
        val file = recentPasswordsFile(context)
        if (value.isEmpty()) {
            return !file.exists() || file.delete()
        }
        if (file.exists() && !file.delete()) return false

        return runCatching {
            encryptedFile(context, file).openFileOutput().use { stream ->
                stream.write(value.toByteArray(Charsets.UTF_8))
            }
            true
        }.getOrDefault(false)
    }

    private fun recentPasswordsFile(context: Context): File =
        File(context.filesDir, RECENT_PASSWORDS_FILE_NAME)

    private fun encryptedFile(context: Context, file: File): EncryptedFile {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedFile.Builder(
            context,
            file,
            masterKey,
            EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
    }

    private fun decryptWithKeystore(cipherTextBase64: String): String {
        if (cipherTextBase64.isBlank()) return ""
        val payload = Base64.decode(cipherTextBase64, Base64.NO_WRAP)
        val buffer = ByteBuffer.wrap(payload)
        val ivSize = buffer.int
        if (ivSize <= 0 || ivSize > 32 || buffer.remaining() <= ivSize) return ""

        val iv = ByteArray(ivSize)
        buffer.get(iv)
        val encryptedBytes = ByteArray(buffer.remaining())
        buffer.get(encryptedBytes)

        val cipher = Cipher.getInstance(CIPHER_TRANSFORMATION)
        val gcmSpec = GCMParameterSpec(GCM_TAG_SIZE_BITS, iv)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), gcmSpec)
        return String(cipher.doFinal(encryptedBytes), Charsets.UTF_8)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEYSTORE_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEYSTORE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }
}
