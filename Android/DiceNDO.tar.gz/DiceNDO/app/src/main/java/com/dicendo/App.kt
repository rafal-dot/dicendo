package com.dicendo

import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

internal fun appendIfFits(current: String, addition: String): String {
    if (addition.isEmpty()) return current
    return if (current.length + addition.length <= MAX_FIELD_LEN) current + addition else current
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun DiceNDOApp() {
    MaterialTheme {
        val focusManager = LocalFocusManager.current
        val clipboard = LocalClipboardManager.current

        var rolls by remember { mutableStateOf("") }
        var dirs by remember { mutableStateOf("") }
        var order by remember { mutableStateOf("") }


        var activeField by remember { mutableStateOf(Field.Rolls) }
        var orderKbd by remember { mutableStateOf(OrderKbd.K1) }
        var showHelp by remember { mutableStateOf(false) }
        var showOptions by remember { mutableStateOf(false) }
        var showAlphabetsPanel by remember { mutableStateOf(false) }
        var showRecentPasswordsLimitWarning by remember { mutableStateOf(false) }

        val context = LocalContext.current

// Keep help WebView instance for the whole app session so help remembers
// its page + scroll position while the app is running (but not across restarts).
        val helpWebView = remember(context) {
            WebView(context).apply {
                settings.javaScriptEnabled = false
                settings.domStorageEnabled = false
                loadUrl("file:///android_asset/help/index.html")
            }
        }
        val settingsScope = rememberCoroutineScope()
        var numericNStr by remember { mutableStateOf("100") }
        var alphabetId by remember { mutableStateOf(Alphabets.DEFAULT_ID) }
        var recentPasswords by remember { mutableStateOf(emptyList<String>()) }
        var savePasswordBeforeClear by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            SettingsStore.alphabetIdFlow(context).collectLatest { alphabetId = it }
        }

        LaunchedEffect(Unit) {
            SettingsStore.numericNFlow(context).collectLatest { numericNStr = it }
        }

        LaunchedEffect(Unit) {
            SettingsStore.recentPasswordsFlow(context).collectLatest { recentPasswords = it }
        }

        LaunchedEffect(Unit) {
            SettingsStore.savePasswordBeforeClearFlow(context).collectLatest { savePasswordBeforeClear = it }
        }
        val alphabetSpec = remember(alphabetId) { Alphabets.byId(alphabetId) }

        val numericNBig = remember(numericNStr) {
            try {
                java.math.BigInteger(numericNStr)
            } catch (_: Exception) {
                java.math.BigInteger("100")
            }
        }

        val orderParsed = remember(order) { Validation.parseOrderLoose(order) }

        // No extra text on startup: show empty password area until generation is possible.
        val computed = remember(rolls, dirs, order, alphabetId, numericNStr) {
            try {
                val r = Generator.generate(
                    rolls,
                    dirs,
                    order,
                    alphabetSpec.alphabet,
                    numericN = if (alphabetSpec.isNumeric) numericNBig else null
                )
                UiState.Ok(r.password, r.effectiveLen, r.bitsOfEntropy)
            } catch (_: Exception) {
                UiState.Empty
            }
        }

        val entropyLabel = when (computed) {
            is UiState.Ok -> when {
                computed.bitsOfEntropy < 56 -> "low"
                computed.bitsOfEntropy < 72 -> "medium"
                computed.bitsOfEntropy < 112 -> "high"
                else -> "very high"
            }

            else -> null
        }

        val passwordCardColor = when (computed) {
            is UiState.Ok -> when {
                computed.bitsOfEntropy < 56 -> SpecColors.Red
                computed.bitsOfEntropy < 72 -> SpecColors.Yellow
                else -> SpecColors.Green
            }

            else -> MaterialTheme.colorScheme.surfaceVariant
        }

        val saveCurrentPasswordIfEnabled = {
            val currentPassword = (computed as? UiState.Ok)?.password
            if (savePasswordBeforeClear && !currentPassword.isNullOrBlank()) {
                val updated = (listOf(currentPassword) + recentPasswords).take(SettingsStore.MAX_RECENT_PASSWORDS)
                recentPasswords = updated
                settingsScope.launch { SettingsStore.setRecentPasswords(context, updated) }
            }
        }

        val clearAllInputs = {
            // FSD: clear ALL inputs and switch active panel back to Rolls
            rolls = ""
            dirs = ""
            order = ""
            orderKbd = OrderKbd.K1
            activeField = Field.Rolls
            focusManager.clearFocus()
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header row (single; avoids duplicate narrow bars)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showOptions = true }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Options")
                    }
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = alphabetSpec.statusCode,
                        modifier = Modifier.clickable { showAlphabetsPanel = true }
                    )
                }
                Spacer(Modifier.weight(1f))


                Text(
                    "DiceNDO",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.weight(1f))

                TextButton(onClick = { showHelp = true }) {
                    Text("\u2370", style = MaterialTheme.typography.titleLarge, color = Color.Black)
                }
            }

            Spacer(Modifier.height(8.dp))

            // ===== Password panel (top) =====
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = passwordCardColor),
                border = BorderStroke(3.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {

                    // FSD: [X] | centered 2-lines | [COPY]
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                val currentPassword = (computed as? UiState.Ok)?.password
                                val isAtRecentPasswordsLimit =
                                    recentPasswords.size >= SettingsStore.MAX_RECENT_PASSWORDS
                                if (savePasswordBeforeClear && !currentPassword.isNullOrBlank() && isAtRecentPasswordsLimit) {
                                    showRecentPasswordsLimitWarning = true
                                    return@Button
                                }
                                saveCurrentPasswordIfEnabled()
                                clearAllInputs()
                            }
                        ) {
                            Text(
                                if (savePasswordBeforeClear) CLEAR_ADD_SYMBOL else CLEAR_SYMBOL,
                                style = MaterialTheme.typography.titleLarge
                            )
                        }

                        Spacer(Modifier.weight(1f))

                        if (computed is UiState.Ok) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "Entropy: ${computed.bitsOfEntropy} bits / $entropyLabel",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Text(
                                    "Length: ${computed.effectiveLen}",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        } else {
                            // FSD: no text at all on startup / when invalid
                            Spacer(Modifier.height(KEY_H))
                        }

                        Spacer(Modifier.weight(1f))

                        Button(
                            onClick = {
                                val pass = (computed as? UiState.Ok)?.password ?: return@Button
                                clipboard.setText(AnnotatedString(pass))
                            },
                            enabled = computed is UiState.Ok
                        ) { Text("COPY") }
                    }

                    Spacer(Modifier.height(8.dp))

                    val passText = (computed as? UiState.Ok)?.password ?: ""
                    ScrollableMonoLine(
                        value = passText,
                        fontSizeSp = 22,
                        bold = true
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // ===== Inputs (center) =====
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.Top
            ) {
                RollsPanel(
                    value = rolls,
                    isActive = activeField == Field.Rolls,
                    onActivate = { activeField = Field.Rolls; focusManager.clearFocus() }
                )
                Spacer(Modifier.height(8.dp))
                DirectionsPanel(
                    value = dirs,
                    isActive = activeField == Field.Directions,
                    onActivate = { activeField = Field.Directions; focusManager.clearFocus() }
                )
                Spacer(Modifier.height(8.dp))
                OrderPanel(
                    value = order,
                    parsed = orderParsed,
                    isActive = activeField == Field.Order,
                    onActivate = { activeField = Field.Order; focusManager.clearFocus() }
                )
            }

            // ===== Keypads (bottom) =====
            when (activeField) {
                Field.Rolls -> RollsKeypad(
                    onDigit = { c -> rolls = appendIfFits(rolls, c.toString()) },
                    onBackspace = { if (rolls.isNotEmpty()) rolls = rolls.dropLast(1) },
                    onClear = { rolls = "" },
                    onPaste = {
                        val txt = clipboard.getText()?.text ?: ""
                        val filtered = Validation.filterRollsPaste(txt)
                        rolls = appendIfFits(rolls, filtered)
                    }
                )

                Field.Directions -> DirectionsKeypad(
                    onDir = { c -> dirs = appendIfFits(dirs, c.toString()) },
                    onBackspace = { if (dirs.isNotEmpty()) dirs = dirs.dropLast(1) },
                    onClear = { dirs = "" },
                    onPaste = {
                        val txt = clipboard.getText()?.text ?: ""
                        val filtered = Validation.filterDirectionsPaste(txt)
                        dirs = appendIfFits(dirs, filtered)
                    }
                )

                Field.Order -> OrderKeypad(
                    parsed = orderParsed,
                    mode = orderKbd,
                    onModeSwitch = {
                        orderKbd = if (orderKbd == OrderKbd.K1) OrderKbd.K2 else OrderKbd.K1
                    },
                    onAppendText = { add -> order = appendIfFits(order, add) },
                    onBackspaceChar = { if (order.isNotEmpty()) order = order.dropLast(1) },
                    onBackspaceToken = {
                        val nums = Validation.parseOrderLoose(order).numbers
                        order = if (nums.isEmpty()) "" else nums.dropLast(1).joinToString("-").let {
                            if (it.isEmpty()) "" else "$it-"
                        }
                    },
                    onClear = { order = "" },
                    onPaste = {
                        val txt = clipboard.getText()?.text ?: ""
                        val filtered = Validation.filterOrderPaste(txt)
                        order = appendIfFits(order, filtered)
                    }
                )
            }
        }

        if (showOptions) {
            OptionsDialog(
                recentPasswords = recentPasswords,
                alphabetSpec = alphabetSpec,
                numericNStr = numericNStr,
                savePasswordBeforeClear = savePasswordBeforeClear,
                onOpenAlphabets = {
                    showOptions = false
                    showAlphabetsPanel = true
                },
                onSavePasswordBeforeClearChange = { enabled ->
                    savePasswordBeforeClear = enabled
                    settingsScope.launch { SettingsStore.setSavePasswordBeforeClear(context, enabled) }
                },
                onCopyList = {
                    if (recentPasswords.isNotEmpty()) {
                        clipboard.setText(AnnotatedString(recentPasswords.joinToString("\n")))
                    }
                },
                onClearList = {
                    recentPasswords = emptyList()
                    settingsScope.launch { SettingsStore.setRecentPasswords(context, emptyList()) }
                },
                onDismiss = { showOptions = false }
            )
        }

        if (showAlphabetsPanel) {
            AlphabetsDialog(
                selectedId = alphabetId,
                numericNStr = numericNStr,
                onNumericNChange = { newN ->
                    numericNStr = newN
                    settingsScope.launch { SettingsStore.setNumericN(context, newN) }
                },
                onSelect = { id ->
                    alphabetId = id
                    settingsScope.launch { SettingsStore.setAlphabetId(context, id) }
                },
                onDismiss = { showAlphabetsPanel = false }
            )
        }

        if (showHelp) {
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                HelpAssetsDialog(helpWebView = helpWebView, onClose = { showHelp = false })
            }
        }

        if (showRecentPasswordsLimitWarning) {
            AlertDialog(
                onDismissRequest = { showRecentPasswordsLimitWarning = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showRecentPasswordsLimitWarning = false
                            saveCurrentPasswordIfEnabled()
                            clearAllInputs()
                        }
                    ) { Text("CONTINUE") }
                },
                dismissButton = {
                    TextButton(onClick = { showRecentPasswordsLimitWarning = false }) { Text("CANCEL") }
                },
                title = { Text("Recent passwords limit reached") },
                text = {
                    Text("The recent passwords list already contains ${SettingsStore.MAX_RECENT_PASSWORDS} items. Continuing will replace the oldest entry.")
                }
            )
        }
    }
}


@Composable
private fun HelpAssetsDialog(helpWebView: WebView, onClose: () -> Unit) {
    var canGoBack by remember { mutableStateOf(helpWebView.canGoBack()) }
    BackHandler(enabled = true) {
        val wv = helpWebView
        if (wv.canGoBack()) {
            wv.goBack()
        } else {
            onClose()
        }
    }

    // Full-screen overlay (not a dialog)
    Surface(
        modifier = Modifier.fillMaxSize(),
        tonalElevation = 2.dp
    ) {
        Column(Modifier
            .fillMaxSize()
            .safeDrawingPadding()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val wv = helpWebView
                        if (wv.canGoBack()) wv.goBack()
                    },
                    enabled = canGoBack
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }

                Text(
                    "Help",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )

                TextButton(onClick = onClose) { Text("Close") }
            }

            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { helpWebView },
                update = { view ->
                    // Update back availability whenever navigation changes.
                    view.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(v: WebView?, url: String?) {
                            canGoBack = v?.canGoBack() == true
                        }
                    }
                    canGoBack = view.canGoBack()
                }
            )
        }
    }
}

/* ===== STATE ===== */

private sealed class UiState {
    data class Ok(val password: String, val effectiveLen: Int, val bitsOfEntropy: Int) : UiState()
    data object Empty : UiState()
}

/* ===== SHARED UI ===== */
@Composable
private fun OptionsDialog(
    recentPasswords: List<String>,
    alphabetSpec: AlphabetSpec,
    numericNStr: String,
    savePasswordBeforeClear: Boolean,
    onOpenAlphabets: () -> Unit,
    onSavePasswordBeforeClearChange: (Boolean) -> Unit,
    onCopyList: () -> Unit,
    onClearList: () -> Unit,
    onDismiss: () -> Unit
) {
    var showClearListConfirm by remember { mutableStateOf(false) }
    val recentPasswordsScroll = rememberScrollState()
    val scrollScope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Options") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Alphabet:", fontWeight = FontWeight.Bold)
                Text(
                    text = if (alphabetSpec.isNumeric) {
                        "${alphabetSpec.shortDescEn} ($numericNStr)"
                    } else {
                        "${alphabetSpec.shortDescEn} (${alphabetSpec.alphabet.length})"
                    }
                )
                Text(
                    text = if (alphabetSpec.isNumeric) {
                        numericAlphabetPreview(numericNStr)
                    } else {
                        alphabetSpec.alphabet
                    },
                    fontFamily = FontFamily.Monospace
                )
                Button(
                    onClick = onOpenAlphabets,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CHANGE")
                }

                HorizontalDivider()

                Text("Clear behavior", fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Save current password before clear",
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = savePasswordBeforeClear,
                        onCheckedChange = onSavePasswordBeforeClearChange
                    )
                }

                HorizontalDivider()

                Text("Recent passwords", fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showClearListConfirm = true },
                        enabled = recentPasswords.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) { Text(CLEAR_SYMBOL) }
                    Button(
                        onClick = onCopyList,
                        enabled = recentPasswords.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) { Text("COPY") }
                }

                if (recentPasswords.isEmpty()) {
                    Text("No recent passwords.")
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(recentPasswordsScroll),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            recentPasswords.forEachIndexed { index, value ->
                                Text(
                                    text = "${index + 1}. $value",
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(Modifier.width(6.dp))
                        Column {
                            IconButton(
                                onClick = {
                                    scrollScope.launch {
                                        val target = (recentPasswordsScroll.value - 120).coerceAtLeast(0)
                                        recentPasswordsScroll.animateScrollTo(target)
                                    }
                                },
                                enabled = recentPasswordsScroll.canScrollBackward
                            ) {
                                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Scroll up")
                            }
                            IconButton(
                                onClick = {
                                    scrollScope.launch {
                                        val target = (recentPasswordsScroll.value + 120)
                                            .coerceAtMost(recentPasswordsScroll.maxValue)
                                        recentPasswordsScroll.animateScrollTo(target)
                                    }
                                },
                                enabled = recentPasswordsScroll.canScrollForward
                            ) {
                                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Scroll down")
                            }
                        }
                    }
                }
            }
        }
    )

    if (showClearListConfirm) {
        AlertDialog(
            onDismissRequest = { showClearListConfirm = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearList()
                        showClearListConfirm = false
                    }
                ) { Text("YES") }
            },
            dismissButton = {
                TextButton(onClick = { showClearListConfirm = false }) { Text("CANCEL") }
            },
            title = { Text("Clear list?") },
            text = { Text("Are you sure you want to clear recent passwords?") }
        )
    }
}

@Composable
private fun AlphabetsDialog(
    selectedId: Int,
    numericNStr: String,
    onNumericNChange: (String) -> Unit,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var infoId by remember { mutableStateOf<Int?>(null) }
    val specToShow = remember(infoId) { infoId?.let { Alphabets.byId(it) } }
    val scroll = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Alphabets") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Alphabets.ALL.forEach { spec ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(spec.id) }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (spec.id == selectedId),
                            onClick = { onSelect(spec.id) }
                        )

                        Spacer(Modifier.width(8.dp))

                        Text(
                            text = if (spec.isNumeric) "${spec.shortDescEn} ($numericNStr)" else "${spec.shortDescEn} (${spec.alphabet.length})",
                            modifier = Modifier.weight(1f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(Modifier.width(8.dp))

                        IconButton(onClick = { infoId = spec.id }) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = "Alphabet info"
                            )
                        }
                    }
                }

                if (selectedId == 7) {
                    Spacer(Modifier.height(6.dp))
                    Text("n (range 0..n-1)", fontWeight = FontWeight.Bold)

                    val curN = numericNStr.toIntOrNull()?.coerceIn(2, 256) ?: 100
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(
                            onClick = {
                                val next = (curN - 1).coerceAtLeast(2)
                                onNumericNChange(next.toString())
                            },
                            enabled = curN > 2
                        ) { Text("-") }

                        Text(
                            text = curN.toString(),
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )

                        TextButton(
                            onClick = {
                                val next = (curN + 1).coerceAtMost(256)
                                onNumericNChange(next.toString())
                            },
                            enabled = curN < 256
                        ) { Text("+") }
                    }

                    Spacer(Modifier.height(2.dp))
                    Text("Allowed range: 2..256")
                }
            }
        }
    )

    if (specToShow != null) {
        AlertDialog(
            onDismissRequest = { infoId = null },
            confirmButton = { TextButton(onClick = { infoId = null }) { Text("Close") } },
            title = { Text("Alphabet preview") },
            text = {
                Column(modifier = Modifier.verticalScroll(scroll)) {
                    Text(
                        text = specToShow.fullDescEn,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (specToShow.isNumeric) numericAlphabetPreview(numericNStr) else specToShow.alphabet,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        )
    }
}

private fun numericAlphabetPreview(nStr: String): String {
    val nInt = nStr.toIntOrNull()?.coerceIn(2, 256) ?: 100
    val n = java.math.BigInteger.valueOf(nInt.toLong())
    if (n <= java.math.BigInteger.ONE) return "n = $n (range: 0..0)"
    val maxPreview = 50
    val previewCount = try {
        n.min(java.math.BigInteger.valueOf(maxPreview.toLong())).toInt()
    } catch (_: Exception) {
        maxPreview
    }
    val sb = StringBuilder()
    sb.append("List of random numbers\n")
    sb.append("range: 0..").append(n.subtract(java.math.BigInteger.ONE)).append("\n\n")
    sb.append("preview: ")
    for (i in 0 until previewCount) {
        if (i > 0) sb.append("-")
        sb.append(i)
    }
    if (n > java.math.BigInteger.valueOf(maxPreview.toLong())) sb.append("-...")
    return sb.toString()
}
