package com.dicendo

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Composable
internal fun ScrollableMonoLine(
    value: String,
    fontSizeSp: Int,
    bold: Boolean
) {
    val scrollState = rememberScrollState()
    val scope: CoroutineScope = rememberCoroutineScope()

    // FSD: when content grows, show last typed characters (scroll to end)
    LaunchedEffect(value) {
        scrollState.scrollTo(scrollState.maxValue)
    }

    val showArrows = value.length > 18 && scrollState.maxValue > 0
    val canScrollLeft = scrollState.value > 0
    val canScrollRight = scrollState.value < scrollState.maxValue

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showArrows) {
            if (canScrollLeft) {
                IconButton(
                    onClick = {
                        scope.launch {
                            scrollState.animateScrollTo((scrollState.value - 160).coerceAtLeast(0))
                        }
                    }
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Scroll left") }
            } else {
                Spacer(Modifier.width(48.dp))
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(scrollState)
        ) {
            Text(
                value,
                maxLines = 1,
                style = TextStyle(
                    fontSize = fontSizeSp.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
                )
            )
        }

        if (showArrows) {
            if (canScrollRight) {
                IconButton(
                    onClick = { scope.launch { scrollState.animateScrollTo(scrollState.value + 160) } }
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Scroll right"
                    )
                }
            } else {
                Spacer(Modifier.width(48.dp))
            }
        }
    }
}


@Composable
internal fun PanelHeader(label: String) {
    Text(label, style = MaterialTheme.typography.labelLarge)
}


@Composable
internal fun ActiveBorder(isActive: Boolean): BorderStroke? {
    // FSD: active panel surrounded by a thin frame
    return if (isActive) BorderStroke(1.dp, MaterialTheme.colorScheme.outline) else null
}

/* ===== PANELS ===== */