package com.dicendo

/**
 * Lehmer rank for a permutation of 1..n.
 * Rank range: 0..n!-1
 */
object Lehmer {
    fun rank(perm: List<Int>): BigInt {
        val n = perm.size
        val items = (1..n).toMutableList()

        var rank = BigInt.ofLong(0)
        for (i in 0 until n) {
            val x = perm[i]
            val idx = items.indexOf(x)
            val factor = factorial(n - 1 - i)
            // rank += idx * (n-1-i)!
            rank = BigInt(rank.v.add(BigInt.ofInt(idx).v.multiply(factor.v)))
            items.removeAt(idx)
        }
        return rank
    }

    private fun factorial(n: Int): BigInt {
        var acc = BigInt.ofLong(1)
        for (i in 2..n) acc = acc.multiplyInt(i)
        return acc
    }
}
