package com.dicendo

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln

/**
 * Core DiceNDO algorithm.
 *
 * Interactive rule:
 * - If ORDER is invalid (duplicates/out-of-range), it is ignored until it becomes valid.
 * - Rolls and directions are always used when non-empty and valid.
 */
object Generator {
    const val DICE_FACES: Int = 6
    const val DICE_DIRECTIONS: Int = 4

    data class Result(
        val password: String,
        val effectiveLen: Int,
        val bitsOfEntropy: Int,
        val usedOrder: Boolean
    )

    fun generate(
        rollsString: String,
        directionsString: String,
        orderString: String,
        alphabet: String,
        numericN: java.math.BigInteger? = null
    ): Result {
        val rolls =
            if (rollsString.isBlank()) emptyList() else Validation.parseRollsStrict(rollsString)
        val dirs =
            if (directionsString.isBlank()) emptyList() else Validation.parseDirectionsStrict(
                directionsString
            )
        val orderParsed = Validation.parseOrderLoose(orderString)

        val alphabetLen = alphabet.length

        var randomNumber = BigInt.ofLong(0)
        val usedOrder = orderParsed.isUsablePermutation
        val order = if (usedOrder) orderParsed.numbers else emptyList()

        if (usedOrder) {
            randomNumber = Lehmer.rank(order)
        }

        for (v in rolls) {
            randomNumber = randomNumber.multiplyInt(DICE_FACES).addInt(v % DICE_FACES)
        }

        for (v in dirs) {
            randomNumber = randomNumber.multiplyInt(DICE_DIRECTIONS).addInt(v % DICE_DIRECTIONS)
        }

        val effectiveLen = effectivePasswordLen(
            orderCount = order.size,
            rollsCount = rolls.size,
            directionsCount = dirs.size,
            lnAlphabet = if (numericN != null) lnBigInteger(numericN) else ln(alphabetLen.toDouble())
        )
        val bitsOfEntropy = bitsOfEntropy(
            effectiveLen,
            if (numericN != null) lnBigInteger(numericN) else ln(alphabetLen.toDouble())
        )

        val password = if (numericN != null) {
            toNumericList(randomNumber, numericN, effectiveLen)
        } else {
            toBaseAlphabet(randomNumber, alphabet, effectiveLen).reversed()
        }

        return Result(
            password = password,
            effectiveLen = effectiveLen,
            bitsOfEntropy = bitsOfEntropy,
            usedOrder = usedOrder
        )
    }

    private fun effectivePasswordLen(
        orderCount: Int,
        rollsCount: Int,
        directionsCount: Int,
        lnAlphabet: Double
    ): Int {
        val totalStatesLn =
            lnFactorial(orderCount) +
                    rollsCount * ln(DICE_FACES.toDouble()) +
                    directionsCount * ln(DICE_DIRECTIONS.toDouble())

        val len = floor(totalStatesLn / lnAlphabet)
        return len.toInt().coerceAtLeast(0)
    }

    private fun bitsOfEntropy(effectiveLen: Int, lnAlphabet: Double): Int {
        if (effectiveLen <= 0) return 0
        val bits = ceil(effectiveLen * (lnAlphabet / ln(2.0)))
        return bits.toInt()
    }

    private fun lnBigInteger(x: java.math.BigInteger): Double {
        if (x.signum() <= 0) return Double.NEGATIVE_INFINITY
        // For huge values, toDouble() becomes +/-Infinity; approximate using bitLength.
        val d = x.toDouble()
        if (d.isFinite() && d > 0.0) return ln(d)
        val bits = x.bitLength()
        // x = m * 2^(bits-1), where m in [1,2)
        val shifted = x.shiftRight(bits - 53) // keep ~53 bits
        val m = shifted.toLong().toDouble() / (1L shl 52).toDouble()
        return ln(m) + (bits - 1) * ln(2.0)
    }

    private fun toNumericList(
        value: BigInt,
        n: java.math.BigInteger,
        length: Int
    ): String {
        if (length <= 0) return ""
        var v = value
        val parts = ArrayList<String>(length)
        repeat(length) {
            val (q, r) = v.divRemBig(n)
            v = q
            parts.add(r.toString())
        }
        // The digit extraction is least-significant first, so reverse.
        return parts.asReversed().joinToString(separator = "-")
    }

    private fun toBaseAlphabet(
        value: BigInt,
        alphabet: String,
        length: Int
    ): String {
        if (length <= 0) return ""
        var v = value
        val base = alphabet.length
        val chars = StringBuilder(length)
        repeat(length) {
            val divRem = v.divRem(base)
            v = divRem.first
            val rem = divRem.second
            chars.append(alphabet[rem])
        }
        return chars.toString()
    }

    private fun lnFactorial(n: Int): Double {
        var acc = 0.0
        for (i in 2..n) acc += ln(i.toDouble())
        return acc
    }
}
