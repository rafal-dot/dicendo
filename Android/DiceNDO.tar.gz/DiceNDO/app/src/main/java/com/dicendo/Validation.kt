package com.dicendo

/**
 * Input validation/parsing.
 *
 * The UI prevents entering invalid characters, but the user can also paste text.
 * For paste we filter out disallowed characters.
 *
 * ORDER validation rule (interactive):
 * - Parse integers separated by: space, '.', ',', '-'
 * - If duplicates or invalid values (<1): RED (ignored in generator)
 * - If missing values in 1..maxUsed (where maxUsed is the highest number present): YELLOW (ignored in generator)
 * - If it contains exactly the set {1..maxUsed}: GREEN (used in generator)
 */
object Validation {
    private val ORDER_SPLIT_REGEX = Regex("""[-+*/=:;.,\s]+""")
    private const val ORDER_EMPTY_MESSAGE = "Order empty (ignored)."

    enum class FieldColor { GREEN, YELLOW, RED }

    data class FieldStatus(
        val color: FieldColor,
        val message: String? = null
    )

    data class OrderParse(
        val numbers: List<Int>,
        val usedMax: Int,
        val isUsablePermutation: Boolean,
        val status: FieldStatus
    )

    private fun emptyOrderParse(): OrderParse =
        OrderParse(
            numbers = emptyList(),
            usedMax = 0,
            isUsablePermutation = false,
            status = FieldStatus(FieldColor.YELLOW, ORDER_EMPTY_MESSAGE)
        )

    private fun invalidOrder(
        numbers: List<Int>,
        usedMax: Int,
        color: FieldColor,
        message: String
    ): OrderParse =
        OrderParse(
            numbers = numbers,
            usedMax = usedMax,
            isUsablePermutation = false,
            status = FieldStatus(color, message)
        )

    fun parseRollsStrict(s: String): List<Int> {
        if (s.isBlank()) throw IllegalArgumentException("Enter dice faces (1..6).")
        val out = ArrayList<Int>(s.length)
        for (ch in s) {
            if (ch !in '1'..'6') throw IllegalArgumentException("Faces must be digits 1..6.")
            out.add(ch.digitToInt())
        }
        return out
    }

    fun parseDirectionsStrict(s: String): List<Int> {
        if (s.isBlank()) throw IllegalArgumentException("Enter directions (N/E/S/W).")
        val out = ArrayList<Int>(s.length)
        for (ch in s) {
            when (ch) {
                'n', 'N' -> out.add(0)
                'e', 'E' -> out.add(1)
                's', 'S' -> out.add(2)
                'w', 'W' -> out.add(3)
                else -> throw IllegalArgumentException("Directions must be N/E/S/W.")
            }
        }
        return out
    }

    fun parseOrderLoose(s: String): OrderParse {
        val trimmed = s.trim()
        if (trimmed.isEmpty()) return emptyOrderParse()

        val parts = trimmed
            .split(ORDER_SPLIT_REGEX)
            .filter { it.isNotBlank() }

        if (parts.isEmpty()) return emptyOrderParse()

        val nums = ArrayList<Int>(parts.size)
        for (p in parts) {
            val v = p.toIntOrNull()
                ?: return invalidOrder(
                    numbers = emptyList(),
                    usedMax = 0,
                    color = FieldColor.RED,
                    message = "Order must contain integers separated by -, space, comma, dot, etc."
                )
            nums.add(v)
        }

        // Spec: allow any positive integers, but max must be < 256.
        val maxUsed = nums.maxOrNull() ?: 0

        if (nums.any { it < 1 }) {
            return invalidOrder(
                numbers = nums,
                usedMax = maxUsed,
                color = FieldColor.RED,
                message = "Order values must be positive integers (>=1)."
            )
        }

        if (maxUsed >= 256) {
            return invalidOrder(
                numbers = nums,
                usedMax = maxUsed,
                color = FieldColor.RED,
                message = "Order max must be < 256 (ignored)."
            )
        }

        if (nums.toSet().size != nums.size) {
            return invalidOrder(
                numbers = nums,
                usedMax = maxUsed,
                color = FieldColor.RED,
                message = "Order contains duplicates (ignored)."
            )
        }

        val set = nums.toSet()
        val expected = (1..maxUsed).toSet()

        // Spec: if missing any number in 1..max -> invalid permutation -> YELLOW (ignored).
        if (set != expected) {
            return invalidOrder(
                numbers = nums,
                usedMax = maxUsed,
                color = FieldColor.YELLOW,
                message = "Order must contain each number 1..$maxUsed exactly once (ignored)."
            )
        }

        return OrderParse(
            numbers = nums,
            usedMax = maxUsed,
            isUsablePermutation = true,
            status = FieldStatus(FieldColor.GREEN, null)
        )
    }

    fun filterRollsChar(ch: Char): Char? = if (ch in '1'..'6') ch else null

    fun filterDirectionsChar(ch: Char): Char? = when (ch) {
        'n', 'N', 'e', 'E', 's', 'S', 'w', 'W' -> ch.lowercaseChar()
        else -> null
    }

    fun filterOrderChar(ch: Char): Char? = when {
        ch in '0'..'9' -> ch
        ch == ' ' || ch == '.' || ch == ',' || ch == '-' -> ch
        else -> null
    }

    /** Paste filters (string-level). */
    fun filterRollsPaste(text: String): String =
        buildString { for (c in text) filterRollsChar(c)?.let { append(it) } }

    fun filterDirectionsPaste(text: String): String =
        buildString { for (c in text) filterDirectionsChar(c)?.let { append(it) } }

    fun filterOrderPaste(text: String): String =
        buildString { for (c in text) filterOrderChar(c)?.let { append(it) } }
}
