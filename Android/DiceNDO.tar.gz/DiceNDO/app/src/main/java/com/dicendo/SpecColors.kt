package com.dicendo

import androidx.compose.ui.graphics.Color

/**
 * Spec-defined colors (Excel-like):
 * - red:   #ffc7ce
 * - yellow:#ffeb9c
 * - green: #c6efce
 */
object SpecColors {
    val Red = Color(0xFFFFC7CE)
    val Yellow = Color(0xFFFFEB9C)
    val Green = Color(0xFFC6EFCE)
}
