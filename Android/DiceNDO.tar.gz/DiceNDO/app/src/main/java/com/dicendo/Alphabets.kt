package com.dicendo

data class AlphabetSpec(
    val id: Int,
    val statusCode: String,
    val shortDescEn: String,
    val fullDescEn: String,
    val alphabet: String,
    val isNumeric: Boolean = false
)

object Alphabets {
    val ALL: List<AlphabetSpec> = listOf(
        AlphabetSpec(
            id = 1,
            statusCode = "full",
            shortDescEn = "Alphabet for copy&paste",
            fullDescEn = "Default full alphabet for passwords processed on computers and later used as copy-paste",
            alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()<>-_=+;:,./?"
        ),
        AlphabetSpec(
            id = 2,
            statusCode = "full+",
            shortDescEn = "Full alphabet for copy&paste",
            fullDescEn = "Full alphabet with space and quotation marks for passwords processed on computers and later used as copy-paste",
            alphabet = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()[]{}<>-_=+;:'\",./?"
        ),
        AlphabetSpec(
            id = 3,
            statusCode = "simple",
            shortDescEn = "Simplified alphabet for manual copy",
            fullDescEn = "Simplified alphabet for passwords stored on computers and later manually copied (e.g., from a password manager on a mobile phone to a computer). Characters causing obvious errors related to ambiguity, such as l/1/I, O/0, ;/:, ,/., etc., have been removed",
            alphabet = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&()/?"
        ),
        AlphabetSpec(
            id = 4,
            statusCode = "hand",
            shortDescEn = "Simplified alphabet for handwriting",
            fullDescEn = "A very simplified alphabet for entries written by hand on paper (e.g., for storing them in a sealed envelope). Ambiguities related to characters such as b/6, c/(, x/X, 5/S, g/9, and 2/Z have also been removed.",
            alphabet = "adefhijkmnprtwyzAEFGHJKLMNPQRTY347!@#$%&)/?"
        ),
        AlphabetSpec(
            id = 5,
            statusCode = "hex",
            shortDescEn = "Hexadecimal number",
            fullDescEn = "Hexadecimal numbers can be useful for generating good keys for symmetric encryption",
            alphabet = "0123456789abcdef"
        ),
        AlphabetSpec(
            id = 6,
            statusCode = "dec",
            shortDescEn = "Decimal number",
            fullDescEn = "Decimal digits, why not",
            alphabet = "0123456789"
        ),
        AlphabetSpec(
            id = 7,
            statusCode = "nums",
            shortDescEn = "List of numbers",
            fullDescEn = "List of random numbers",
            alphabet = "",
            isNumeric = true
        )
    )

    const val DEFAULT_ID: Int = 1

    fun byId(id: Int): AlphabetSpec =
        ALL.firstOrNull { it.id == id } ?: ALL.first { it.id == DEFAULT_ID }
}
