package com.dicendo

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
internal fun RollsPanel(value: String, isActive: Boolean, onActivate: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onActivate,
        border = ActiveBorder(isActive)
    ) {
        Column(Modifier.padding(8.dp)) {
            PanelHeader("Faces (1..6)  •  count: ${value.length}")
            Spacer(Modifier.height(2.dp))
            ScrollableMonoLine(value = value, fontSizeSp = 18, bold = true)
            Spacer(Modifier.height(2.dp))
            Text(
                text = " ",
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}


@Composable
internal fun DirectionsPanel(value: String, isActive: Boolean, onActivate: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onActivate,
        border = ActiveBorder(isActive)
    ) {
        Column(Modifier.padding(8.dp)) {
            PanelHeader("Directions (N/E/S/W)  •  count: ${value.length}")
            Spacer(Modifier.height(2.dp))
            ScrollableMonoLine(value = value, fontSizeSp = 18, bold = true)
            Spacer(Modifier.height(2.dp))
            Text(
                text = " ",
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}


@Composable
internal fun OrderPanel(
    value: String,
    parsed: Validation.OrderParse,
    isActive: Boolean,
    onActivate: () -> Unit
) {
    val containerColor = when (parsed.status.color) {
        Validation.FieldColor.GREEN -> SpecColors.Green
        Validation.FieldColor.YELLOW -> SpecColors.Yellow
        Validation.FieldColor.RED -> SpecColors.Red
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        onClick = onActivate,
        border = ActiveBorder(isActive)
    ) {
        Column(Modifier.padding(8.dp)) {
            val maxN = parsed.numbers.maxOrNull() ?: 0
            PanelHeader("Order (1...${maxN})  •  permutation: ${parsed.numbers.size}")
            Spacer(Modifier.height(2.dp))
            ScrollableMonoLine(value = value, fontSizeSp = 18, bold = true)
            Spacer(Modifier.height(2.dp))
            val msg = if (parsed.isUsablePermutation) " " else (parsed.status.message ?: "Order ignored.")
            Text(
                text = msg,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/* ===== KEYPADS ===== */
