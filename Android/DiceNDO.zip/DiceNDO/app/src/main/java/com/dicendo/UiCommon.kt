package com.dicendo

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp

// Which input field is currently active.
enum class Field { Rolls, Directions, Order }
enum class OrderKbd { K1, K2 }

// Spec symbols
const val BACKSPACE_SYMBOL = "\u232B" // U+232B
const val SWITCH_SYMBOL = "\uD83D\uDD01" // U+1F501
val LOCK_CLOSED_SYMBOL = "\uD83D\uDD12" // U+1F512
val LOCK_OPEN_SYMBOL = "\uD83D\uDD13" // U+1F513

const val SAVE_HISTORY_HINT_TITLE = "Password history is off"
const val SAVE_HISTORY_HINT_MESSAGE =
    "To keep cleared passwords in history, enable \"Save current password before clear\" in Options.\n\nThis can be useful when generating multiple passwords in sequence — for example, to later copy them into a password manager.\n\nSaved history is stored locally on this device in an encrypted file."
const val SAVE_HISTORY_HINT_DONT_SHOW_AGAIN = "Don't show again"
const val SAVE_HISTORY_HINT_OK = "OK"
const val SAVE_HISTORY_HINT_OPEN_OPTIONS = "Open Options"

// Spec limits
const val MAX_FIELD_LEN = 1024

// Standard keypad font size baseline (sp)
const val STANDARD_KEY_FONT_SP = 16

// Layout constants
val KEY_H: Dp = 48.dp
val BREAK_H: Dp = 3.dp
