package com.dicendo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun rowVGap(): Dp {
    val sw = LocalConfiguration.current.smallestScreenWidthDp
    return if (sw < 360) 8.dp else 6.dp
}

@Composable
private fun adaptiveKeyHeight(): Dp {
    val h = LocalConfiguration.current.screenHeightDp
    val baseScale = when {
        h <= 640 -> 0.72f
        h <= 700 -> 0.80f
        h <= 760 -> 0.90f
        else -> 1.0f
    }
    // Slight global shrink to give upper panels a bit more vertical room.
    val compactScale = 0.95f
    return (KEY_H * baseScale * compactScale).coerceAtLeast(32.dp)
}

@Composable
internal fun EmptyKeyRow(height: Dp) {
    Spacer(Modifier.height(height))
}


@Composable
internal fun BreakRow() {
    HorizontalDivider(thickness = BREAK_H)
}


@Composable
internal fun RollsKeypad(
    rolls: String,
    onDigit: (Char) -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onPaste: () -> Unit
) {
    val keyH = adaptiveKeyHeight()
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(rowVGap())
    ) {
        // Row 1: [PASTE] [X] [<==]
        KeyRow(
            labels = listOf("PASTE", "CLEAR", "BACKSPACE"),
            enabled = listOf(true, rolls.isNotEmpty(), rolls.isNotEmpty()),
            height = keyH
        ) { label ->
            when (label) {
                "PASTE" -> onPaste()
                "CLEAR" -> onClear()
                "BACKSPACE" -> onBackspace()
            }
        }

        // Row 2: empty
        EmptyKeyRow(height = keyH)

        // Row 3: break
        BreakRow()

        // Row 4: [4] [5] [6]  (double height)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DiceFaceKey("\u2683 4", height = keyH * 2) { onDigit('4') }
            DiceFaceKey("\u2684 5", height = keyH * 2) { onDigit('5') }
            DiceFaceKey("\u2685 6", height = keyH * 2) { onDigit('6') }
        }

// Gap row: keeps row spacing identical to other keypads (replaces "empty" row height that was moved into double-height keys)
        Spacer(Modifier.height(0.dp))

// Row 6: [1] [2] [3]  (double height)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DiceFaceKey("\u2680 1", height = keyH * 2) { onDigit('1') }
            DiceFaceKey("\u2681 2", height = keyH * 2) { onDigit('2') }
            DiceFaceKey("\u2682 3", height = keyH * 2) { onDigit('3') }
        }

// Gap row (was final "empty" row)
        Spacer(Modifier.height(0.dp))
    }
}


@Composable
internal fun RowScope.DiceFaceKey(label: String, height: Dp = KEY_H, onClick: () -> Unit) {
    Button(
        modifier = Modifier
            .weight(1f)
            .height(height),
        onClick = onClick
    ) {
        Text(
            label,
            fontSize = STANDARD_KEY_FONT_SP.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}


@Composable
internal fun DirectionsKeypad(
    dirs: String,
    onDir: (Char) -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onPaste: () -> Unit
) {
    val keyH = adaptiveKeyHeight()
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(rowVGap())
    ) {
        // Row 1: [PASTE] [X] [<==]
        KeyRow(
            labels = listOf("PASTE", "CLEAR", "BACKSPACE"),
            enabled = listOf(true, dirs.isNotEmpty(), dirs.isNotEmpty()),
            height = keyH
        ) { label ->
            when (label) {
                "PASTE" -> onPaste()
                "CLEAR" -> onClear()
                "BACKSPACE" -> onBackspace()
            }
        }

        // Row 2: empty
        EmptyKeyRow(height = keyH)

        // Row 3: break
        BreakRow()

        // Below 'break' this keypad must occupy exactly 4 standard rows in height,
        // without an extra trailing 'empty' row. We do that by making each of the
        // 3 direction rows 4/3 of the standard key height.
        val density = LocalDensity.current
        val keyPx = with(density) { keyH.roundToPx() }
        val targetPx = 4 * keyPx
        val dirRowPx = targetPx / 3
        val usedPx = 3 * dirRowPx
        val remainderPx = targetPx - usedPx
        val DIR_H = with(density) { dirRowPx.toDp() }
        val FIX_H = with(density) { remainderPx.toDp() }

        // Row 4: centered [N]
        KeyRowCentered("N ▲", height = DIR_H) { onDir('N') }

        // Row 5: [W]     [E]
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                modifier = Modifier
                    .width(120.dp)
                    .height(DIR_H),
                onClick = { onDir('W') }
            ) {
                Text(
                    "◀ W",
                    style = TextStyle(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }

            Button(
                modifier = Modifier
                    .width(120.dp)
                    .height(DIR_H),
                onClick = { onDir('E') }
            ) {
                Text(
                    "E ▶",
                    style = TextStyle(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }
        }

        // Row 6: centered [S]
        KeyRowCentered("▼ S", height = DIR_H) { onDir('S') }

        // Pixel-perfect fix to avoid a few-pixels drift due to dp->px rounding
        Spacer(Modifier.height(FIX_H))
    }
}


@Composable
internal fun OrderKeypad(
    order: String,
    parsed: Validation.OrderParse,
    mode: OrderKbd,
    onModeSwitch: () -> Unit,
    onAppendText: (String) -> Unit,
    onBackspaceChar: () -> Unit,
    onBackspaceToken: () -> Unit,
    onClear: () -> Unit,
    onPaste: () -> Unit
) {
    val used = parsed.numbers.toSet()
    val keyH = adaptiveKeyHeight()
    val canClear = order.isNotEmpty()
    val canBackspace = if (mode == OrderKbd.K1) parsed.numbers.isNotEmpty() else order.isNotEmpty()

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(rowVGap())
    ) {
        // FSD order: [PASTE] [X] [<==] then [SWITCH KEYBOARD] then break
        KeyRow(
            labels = listOf("PASTE", "CLEAR", "BACKSPACE"),
            enabled = listOf(true, canClear, canBackspace),
            height = keyH
        ) { label ->
            when (label) {
                "PASTE" -> onPaste()
                "CLEAR" -> onClear()
                "BACKSPACE" -> if (mode == OrderKbd.K1) onBackspaceToken() else onBackspaceChar()
            }
        }

        KeyRowSingle("SWITCH", height = keyH) { onModeSwitch() }
        BreakRow()

        when (mode) {
            OrderKbd.K1 -> {
                KeyRow(
                    labels = listOf("10", "11", "12"),
                    enabled = listOf(!used.contains(10), !used.contains(11), !used.contains(12)),
                    height = keyH,
                    onPress = { onAppendText("${it}-") }
                )
                KeyRow(
                    labels = listOf("7", "8", "9"),
                    enabled = listOf(!used.contains(7), !used.contains(8), !used.contains(9)),
                    height = keyH,
                    onPress = { onAppendText("${it}-") }
                )
                KeyRow(
                    labels = listOf("4", "5", "6"),
                    enabled = listOf(!used.contains(4), !used.contains(5), !used.contains(6)),
                    height = keyH,
                    onPress = { onAppendText("${it}-") }
                )
                KeyRow(
                    labels = listOf("1", "2", "3"),
                    enabled = listOf(!used.contains(1), !used.contains(2), !used.contains(3)),
                    height = keyH,
                    onPress = { onAppendText("${it}-") }
                )
            }

            OrderKbd.K2 -> {
                KeyRow(listOf("7", "8", "9"), height = keyH) { onAppendText(it) }
                KeyRow(listOf("4", "5", "6"), height = keyH) { onAppendText(it) }
                KeyRow(listOf("1", "2", "3"), height = keyH) { onAppendText(it) }
                KeyRow(listOf("0", "-"), height = keyH) { onAppendText(it) }
            }
        }
    }
}

/* ===== KEY ROWS ===== */


@Composable
internal fun KeyRow(
    labels: List<String>,
    enabled: List<Boolean>? = null,
    height: Dp = KEY_H,
    onPress: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        labels.forEachIndexed { idx, label ->
            val isEnabled = enabled?.getOrNull(idx) ?: true
            Button(
                modifier = Modifier
                    .weight(1f)
                    .height(height),
                onClick = { onPress(label) },
                enabled = isEnabled
            ) {
                when (label) {
                    "BACKSPACE" -> Text(
                        BACKSPACE_SYMBOL,
                        style = MaterialTheme.typography.titleLarge
                    )

                    "CLEAR" -> Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = "Clear input"
                    )
                    "SWITCH" -> Text(SWITCH_SYMBOL, style = MaterialTheme.typography.titleLarge)
                    else -> Text(
                        label,
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}


@Composable
internal fun KeyRowSingle(label: String, height: Dp = KEY_H, onPress: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Button(
            modifier = Modifier
                .fillMaxWidth()
                .height(height),
            onClick = onPress
        ) {
            when (label) {
                "SWITCH" -> Icon(Icons.Filled.Sync, contentDescription = "Switch keyboard")
                else -> Text(label)
            }
        }
    }
}


@Composable
internal fun KeyRowCentered(
    label: String,
    height: Dp = KEY_H,
    onPress: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(height),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            modifier = Modifier
                .width(120.dp)
                .height(height),
            onClick = onPress
        ) {
            Text(
                label,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            )
        }

    }
}
