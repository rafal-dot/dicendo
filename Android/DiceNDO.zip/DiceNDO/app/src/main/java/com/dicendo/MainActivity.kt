package com.dicendo

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val initialThemeMode = runBlocking {
            SettingsStore.themeModeFlow(applicationContext).first()
        }
        AppCompatDelegate.setDefaultNightMode(initialThemeMode.toNightMode())

        super.onCreate(savedInstanceState)

        // Lock portrait orientation (spec requirement).
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        setContent {
            DiceNDOApp()
        }
    }
}
