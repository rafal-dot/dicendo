package com.dicendo

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.appcompat.app.AppCompatDelegate

enum class ThemeMode(val storageValue: String) {
    Light("light"),
    Dark("dark"),
    System("system");

    fun toNightMode(): Int = when (this) {
        Light -> AppCompatDelegate.MODE_NIGHT_NO
        Dark -> AppCompatDelegate.MODE_NIGHT_YES
        System -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }

    companion object {
        val DEFAULT: ThemeMode = System

        fun fromStorageValue(value: String?): ThemeMode =
            entries.firstOrNull { it.storageValue == value } ?: DEFAULT

        fun fromNightMode(nightMode: Int): ThemeMode = when (nightMode) {
            AppCompatDelegate.MODE_NIGHT_YES -> Dark
            AppCompatDelegate.MODE_NIGHT_NO -> Light
            else -> System
        }
    }
}

private val LightColors = lightColorScheme()
private val DarkColors = darkColorScheme()

@Composable
fun DiceNDOTheme(
    themeMode: ThemeMode,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val useDarkTheme = when (themeMode) {
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
        ThemeMode.System -> isSystemInDarkTheme()
    }
    val colorScheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && useDarkTheme -> dynamicDarkColorScheme(context)
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !useDarkTheme -> dynamicLightColorScheme(context)
        useDarkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
