package com.dicendo

import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.webkit.WebSettings
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

private val PASS_INFO_PLACEHOLDER_H = 34.dp
private val KEYPAD_CONTENT_GAP = 6.dp
private const val RECENT_PASSWORDS_UNLOCK_WINDOW_MS = 5 * 60 * 1000L

private enum class WalkthroughTarget { Header, Password, Inputs, Keyboard }

private data class HelpScrollPosition(val x: Int, val y: Int)
private data class HelpHistoryEntry(val url: String, val scrollPosition: HelpScrollPosition)

private class HelpNavigationState {
    private val history = ArrayDeque<HelpHistoryEntry>()
    private val savedPositions = mutableMapOf<String, HelpScrollPosition>()
    private var pendingRestoreEntry: HelpHistoryEntry? = null

    fun canGoBack(): Boolean = history.isNotEmpty()

    private fun saveCurrentPagePosition(webView: WebView) {
        val url = webView.url ?: return
        savedPositions[url] = HelpScrollPosition(webView.scrollX, webView.scrollY)
    }

    fun prepareCurrentPageRestore(webView: WebView) {
        val url = webView.url ?: return
        val position = HelpScrollPosition(webView.scrollX, webView.scrollY)
        savedPositions[url] = position
        pendingRestoreEntry = HelpHistoryEntry(url, position)
    }

    fun navigateTo(
        webView: WebView,
        context: Context,
        targetUrl: String,
        useDarkTheme: Boolean
    ) {
        val currentUrl = webView.url
        if (currentUrl != null && currentUrl != targetUrl) {
            val currentPosition = HelpScrollPosition(webView.scrollX, webView.scrollY)
            savedPositions[currentUrl] = currentPosition
            history.addLast(HelpHistoryEntry(currentUrl, currentPosition))
        }
        pendingRestoreEntry =
            savedPositions[targetUrl]?.let { HelpHistoryEntry(targetUrl, it) }
        loadThemedHelpPage(webView, context, targetUrl, useDarkTheme)
    }

    fun navigateBack(webView: WebView, context: Context, useDarkTheme: Boolean): Boolean {
        saveCurrentPagePosition(webView)
        val entry = history.removeLastOrNull() ?: return false
        pendingRestoreEntry = entry
        loadThemedHelpPage(webView, context, entry.url, useDarkTheme)
        return true
    }

    fun restoreScrollIfNeeded(webView: WebView, url: String?) {
        val entry = pendingRestoreEntry ?: return
        if (url != entry.url) return
        pendingRestoreEntry = null
        savedPositions[entry.url] = entry.scrollPosition
        webView.postDelayed({ webView.scrollTo(entry.scrollPosition.x, entry.scrollPosition.y) }, 16L)
    }
}

private data class WalkthroughStep(
    val target: WalkthroughTarget?,
    val title: String,
    val message: String
)

private val WALKTHROUGH_STEPS = listOf(
    WalkthroughStep(
        target = null,
        title = "Welcome",
        message =
            "dicendo is a password generator that uses real dice. " +
                "You roll physical dice and the app converts the results into a strong password.\n" +
                "\n" +
                "It may be useful if you want fully random passwords, randomness you can actually see " +
                "and even touch.\n" +
                "\n" +
                "With properly marked dice (for example, with a permanent marker), dicendo can " +
                "use not only face values, but also their orientation and order as sources of " +
                "random data."
    ),
    WalkthroughStep(
        target = WalkthroughTarget.Password,
        title = "Password panel",
        message =
            "Your generated password appears here. You can copy it or clear all input data.\n" +
                    "\n" +
                    "Entropy and length are shown. The color changes from red to yellow to green based on strength."
    ),
    WalkthroughStep(
        target = WalkthroughTarget.Inputs,
        title = "Input panels",
        message =
            "Enter dice faces, directions, and order here. Tap the appropriate subpanel to activate it.\n" +
                    "\n" +
                    "You don’t need to fill all fields, dicendo uses whatever data you provide."
    ),
    WalkthroughStep(
        target = WalkthroughTarget.Keyboard,
        title = "Keyboard",
        message =
            "Use the context-specific keyboard to enter values for the currently active " +
                "subpanel."
    ),
    WalkthroughStep(
        target = WalkthroughTarget.Header,
        title = "Top bar",
        message =
            "Open Options, view the active alphabet, or access Help here.\n" +
                    "\n" +
                    "You can enable encrypted local password storage to generate multiple passwords " +
                    "and later copy them to your password manager."
    )
)

internal fun appendIfFits(current: String, addition: String): String {
    if (addition.isEmpty()) return current
    return if (current.length + addition.length <= MAX_FIELD_LEN) current + addition else current
}

@Composable
private fun ScreenWithFixedKeyboard(
    fallbackKeyboardHeight: androidx.compose.ui.unit.Dp,
    keyboard: @Composable (Modifier) -> Unit,
    content: @Composable (Modifier) -> Unit
) {
    val density = LocalDensity.current
    var keyboardHeightPx by remember { mutableStateOf(0) }
    val keyboardHeightDp = if (keyboardHeightPx > 0) {
        with(density) { keyboardHeightPx.toDp() }
    } else {
        fallbackKeyboardHeight
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        content(
            Modifier
                .fillMaxSize()
                .padding(12.dp)
                .padding(bottom = keyboardHeightDp + KEYPAD_CONTENT_GAP)
                .windowInsetsPadding(WindowInsets.ime)
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(12.dp)
                .onSizeChanged { keyboardHeightPx = it.height }
        ) {
            keyboard(Modifier.fillMaxWidth())
        }
    }
}

private fun configureHelpWebViewTheme(webView: WebView, useDarkTheme: Boolean) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        webView.settings.isAlgorithmicDarkeningAllowed = useDarkTheme
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        @Suppress("DEPRECATION")
        webView.settings.forceDark =
            if (useDarkTheme) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
    } else {
        webView.settings.loadsImagesAutomatically = true
    }
}

private fun injectHelpTheme(html: String, useDarkTheme: Boolean): String {
    val themeClass = if (useDarkTheme) "theme-dark" else "theme-light"
    val bodyTagRegex = "<body(\\s[^>]*)?>".toRegex(RegexOption.IGNORE_CASE)
    val bodyMatch = bodyTagRegex.find(html) ?: return html
    val originalTag = bodyMatch.value
    val updatedTag = if (originalTag.contains("class=", ignoreCase = true)) {
        val classRegex = "class\\s*=\\s*\"([^\"]*)\"".toRegex(RegexOption.IGNORE_CASE)
        val classMatch = classRegex.find(originalTag)
        if (classMatch != null) {
            val classes = classMatch.groupValues[1].trim()
            val mergedClasses = if (classes.isEmpty()) themeClass else "$classes $themeClass"
            originalTag.replace(classMatch.value, "class=\"$mergedClasses\"")
        } else {
            originalTag.dropLast(1) + " class=\"$themeClass\">"
        }
    } else {
        originalTag.dropLast(1) + " class=\"$themeClass\">"
    }
    return html.replaceRange(bodyMatch.range, updatedTag)
}

private fun isHelpHtmlUrl(url: Uri?): Boolean {
    return url?.scheme == "file" &&
        url.path?.startsWith("/android_asset/help/") == true &&
        url.path?.endsWith(".html") == true
}

private fun helpAssetPath(url: String?): String? {
    val parsed = runCatching { Uri.parse(url) }.getOrNull() ?: return null
    val path = parsed.path ?: return null
    if (parsed.scheme != "file" || !path.startsWith("/android_asset/help/") || !path.endsWith(".html")) {
        return null
    }
    return path.removePrefix("/android_asset/")
}

private fun loadThemedHelpPage(
    webView: WebView,
    context: Context,
    url: String,
    useDarkTheme: Boolean
) {
    val assetPath = helpAssetPath(url) ?: return
    val html = runCatching {
        context.assets.open(assetPath).bufferedReader(Charsets.UTF_8).use { it.readText() }
    }.getOrNull() ?: return
    val themedHtml = injectHelpTheme(html, useDarkTheme)
    webView.loadDataWithBaseURL(url, themedHtml, "text/html", "UTF-8", url)
}

private fun createHelpWebViewClient(
    webView: WebView,
    context: Context,
    useDarkTheme: Boolean,
    navigationState: HelpNavigationState,
    onPageFinished: (WebView?) -> Unit = {}
): WebViewClient =
    object : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {
            val targetUrl = request?.url?.toString() ?: return false
            if (!isHelpHtmlUrl(request.url)) return false
            navigationState.navigateTo(webView, context, targetUrl, useDarkTheme)
            return true
        }

        override fun onPageFinished(v: WebView?, url: String?) {
            if (v != null) {
                navigationState.restoreScrollIfNeeded(v, url)
            }
            onPageFinished(v)
        }
    }

@Composable
private fun WalkthroughOverlay(
    stepIndex: Int,
    targetBounds: Rect?,
    onNext: () -> Unit,
    onSkip: () -> Unit
) {
    val step = WALKTHROUGH_STEPS[stepIndex]
    val density = LocalDensity.current
    val contentScroll = rememberScrollState()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.72f))
    ) {
        val maxWidthPx = with(density) { this@BoxWithConstraints.maxWidth.toPx() }
        val maxHeightPx = with(density) { this@BoxWithConstraints.maxHeight.toPx() }
        val horizontalPaddingPx = with(density) { 16.dp.toPx() }
        val verticalPaddingPx = with(density) { 16.dp.toPx() }
        val targetGapPx = with(density) { 20.dp.toPx() }
        val introCardMaxHeight = with(density) { this@BoxWithConstraints.maxHeight * 0.8f }
        val anchoredCardMaxHeightPx = maxHeightPx * 0.42f
        val anchoredCardMaxHeightDp = with(density) { anchoredCardMaxHeightPx.toDp() }
        val isIntroStep = step.target == null

        if (isIntroStep) {
            Card(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(20.dp)
                    .heightIn(max = introCardMaxHeight),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(contentScroll),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Quick walkthrough",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(step.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(step.message)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onSkip) { Text("Skip") }
                        Button(onClick = onNext) { Text("Start") }
                    }
                }
            }
            return@BoxWithConstraints
        }

        if (targetBounds != null) {
            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            x = targetBounds.left.toInt(),
                            y = targetBounds.top.toInt()
                        )
                    }
                    .width(with(density) { targetBounds.width.toDp() })
                    .height(with(density) { targetBounds.height.toDp() })
            ) {
                Card(
                    modifier = Modifier.fillMaxSize(),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    border = BorderStroke(3.dp, MaterialTheme.colorScheme.primary)
                ) {}
            }
        }

        val cardY = if (targetBounds == null) {
            (maxHeightPx - anchoredCardMaxHeightPx) / 2f
        } else {
            val preferredBelowY = targetBounds.bottom + targetGapPx
            val fitsBelow = preferredBelowY + anchoredCardMaxHeightPx <= maxHeightPx - verticalPaddingPx
            val preferredAboveY = targetBounds.top - targetGapPx - anchoredCardMaxHeightPx
            val fitsAbove = preferredAboveY >= verticalPaddingPx
            when {
                fitsBelow -> preferredBelowY
                fitsAbove -> preferredAboveY
                else -> (maxHeightPx - anchoredCardMaxHeightPx) / 2f
            }.coerceIn(
                verticalPaddingPx,
                (maxHeightPx - anchoredCardMaxHeightPx - verticalPaddingPx).coerceAtLeast(verticalPaddingPx)
            )
        }
        val cardX = if (targetBounds == null) {
            horizontalPaddingPx
        } else {
            targetBounds.left
                .coerceAtLeast(horizontalPaddingPx)
                .coerceAtMost((maxWidthPx - horizontalPaddingPx - with(density) { 320.dp.toPx() }).coerceAtLeast(horizontalPaddingPx))
        }

        Card(
            modifier = Modifier
                .offset { IntOffset(cardX.toInt(), cardY.toInt()) }
                .width(with(density) { (maxWidthPx - horizontalPaddingPx * 2).coerceAtMost(320.dp.toPx()).toDp() })
                .heightIn(max = anchoredCardMaxHeightDp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(contentScroll),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Quick walkthrough ${stepIndex + 1}/${WALKTHROUGH_STEPS.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(step.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(step.message)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onSkip) { Text("Skip") }
                    Button(onClick = onNext) {
                        Text(if (stepIndex == WALKTHROUGH_STEPS.lastIndex) "Done" else "Next")
                    }
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun DiceNDOApp() {
    val context = LocalContext.current
    var themeMode by remember {
        mutableStateOf(ThemeMode.fromNightMode(AppCompatDelegate.getDefaultNightMode()))
    }
    val systemDarkTheme = isSystemInDarkTheme()
    val useDarkTheme = when (themeMode) {
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
        ThemeMode.System -> systemDarkTheme
    }

    LaunchedEffect(Unit) {
        SettingsStore.themeModeFlow(context).collectLatest { themeMode = it }
    }

    DiceNDOTheme(themeMode = themeMode) {
        val focusManager = LocalFocusManager.current
        val clipboard = LocalClipboardManager.current

        var rolls by rememberSaveable { mutableStateOf("") }
        var dirs by rememberSaveable { mutableStateOf("") }
        var order by rememberSaveable { mutableStateOf("") }


        var activeField by rememberSaveable { mutableStateOf(Field.Rolls) }
        var orderKbd by rememberSaveable { mutableStateOf(OrderKbd.K1) }
        var showHelp by remember { mutableStateOf(false) }
        var showOptions by remember { mutableStateOf(false) }
        var showAlphabetsPanel by remember { mutableStateOf(false) }
        var showRecentPasswordsLimitWarning by remember { mutableStateOf(false) }
        var showSaveHistoryHintDialog by rememberSaveable { mutableStateOf(false) }
        var pendingClearFromHint by rememberSaveable { mutableStateOf(false) }
        var pendingClearPassword by rememberSaveable { mutableStateOf<String?>(null) }
        var pendingClearSaveEnabledDuringOptions by rememberSaveable { mutableStateOf(false) }
        var recentPasswordsUnlocked by rememberSaveable { mutableStateOf(false) }
        var recentPasswordsUnlockUntilMs by rememberSaveable { mutableStateOf(0L) }
        var recentPasswordsUnlockError by remember { mutableStateOf<String?>(null) }
        var showWeakUnlockNotice by rememberSaveable { mutableStateOf(false) }

// Keep help WebView instance for the whole app session so help remembers
// its page + scroll position while the app is running (but not across restarts).
        val helpNavigationState = remember { HelpNavigationState() }
        val helpWebView = remember(context) {
            WebView(context).apply {
                settings.javaScriptEnabled = false
                settings.domStorageEnabled = false
            }
        }
        LaunchedEffect(helpWebView, helpNavigationState, useDarkTheme) {
            helpNavigationState.prepareCurrentPageRestore(helpWebView)
            helpWebView.webViewClient =
                createHelpWebViewClient(helpWebView, context, useDarkTheme, helpNavigationState)
            configureHelpWebViewTheme(helpWebView, useDarkTheme)
            val currentUrl = helpWebView.url ?: "file:///android_asset/help/index.html"
            loadThemedHelpPage(helpWebView, context, currentUrl, useDarkTheme)
        }
        val settingsScope = rememberCoroutineScope()
        var numericNStr by remember { mutableStateOf("100") }
        var alphabetId by remember { mutableStateOf(Alphabets.DEFAULT_ID) }
        var recentPasswords by remember { mutableStateOf(emptyList<String>()) }
        var savePasswordBeforeClear by remember { mutableStateOf(false) }
        var shouldShowSaveHistoryHintDialog by remember { mutableStateOf(true) }
        var shouldShowWeakUnlockNotice by remember { mutableStateOf(true) }
        var hasCompletedWalkthrough by remember { mutableStateOf(false) }
        var walkthroughStepIndex by rememberSaveable { mutableStateOf<Int?>(null) }
        val walkthroughBounds = remember { mutableStateMapOf<WalkthroughTarget, Rect>() }

        LaunchedEffect(Unit) {
            SettingsStore.alphabetIdFlow(context).collectLatest { alphabetId = it }
        }

        LaunchedEffect(Unit) {
            SettingsStore.numericNFlow(context).collectLatest { numericNStr = it }
        }

        LaunchedEffect(Unit) {
            SettingsStore.recentPasswordsFlow(context).collectLatest { recentPasswords = it }
        }

        LaunchedEffect(Unit) {
            SettingsStore.savePasswordBeforeClearFlow(context).collectLatest { savePasswordBeforeClear = it }
        }
        LaunchedEffect(Unit) {
            SettingsStore.showSaveHistoryHintDialogFlow(context)
                .collectLatest { shouldShowSaveHistoryHintDialog = it }
        }
        LaunchedEffect(Unit) {
            SettingsStore.showWeakUnlockNoticeFlow(context)
                .collectLatest { shouldShowWeakUnlockNotice = it }
        }
        LaunchedEffect(Unit) {
            SettingsStore.hasCompletedWalkthroughFlow(context).collectLatest { completed ->
                hasCompletedWalkthrough = completed
                if (!completed && walkthroughStepIndex == null) {
                    walkthroughStepIndex = 0
                }
            }
        }
        LaunchedEffect(recentPasswordsUnlocked, recentPasswordsUnlockUntilMs) {
            if (!recentPasswordsUnlocked) return@LaunchedEffect
            val remaining = recentPasswordsUnlockUntilMs - SystemClock.elapsedRealtime()
            if (remaining <= 0L) {
                recentPasswordsUnlocked = false
                recentPasswordsUnlockUntilMs = 0L
                recentPasswordsUnlockError = null
                return@LaunchedEffect
            }
            delay(remaining)
            if (recentPasswordsUnlocked && SystemClock.elapsedRealtime() >= recentPasswordsUnlockUntilMs) {
                recentPasswordsUnlocked = false
                recentPasswordsUnlockUntilMs = 0L
                recentPasswordsUnlockError = null
            }
        }
        val alphabetSpec = remember(alphabetId) { Alphabets.byId(alphabetId) }

        val numericNBig = remember(numericNStr) {
            try {
                java.math.BigInteger(numericNStr)
            } catch (_: Exception) {
                java.math.BigInteger("100")
            }
        }

        val orderParsed = remember(order) { Validation.parseOrderLoose(order) }
        val upperPanelsScroll = rememberScrollState()
        val smallestWidthDp = LocalConfiguration.current.smallestScreenWidthDp
        // Keep content visible already on first frame, before keyboard onSizeChanged reports.
        val startupKeyboardFallback = if (smallestWidthDp < 360) 351.dp else 327.dp

        // No extra text on startup: show empty password area until generation is possible.
        val computed = remember(rolls, dirs, order, alphabetId, numericNStr) {
            try {
                val r = Generator.generate(
                    rolls,
                    dirs,
                    order,
                    alphabetSpec.alphabet,
                    numericN = if (alphabetSpec.isNumeric) numericNBig else null
                )
                UiState.Ok(r.password, r.effectiveLen, r.bitsOfEntropy)
            } catch (_: Exception) {
                UiState.Empty
            }
        }

        val entropyLabel = when (computed) {
            is UiState.Ok -> when {
                computed.bitsOfEntropy < 56 -> "low"
                computed.bitsOfEntropy < 72 -> "medium"
                computed.bitsOfEntropy < 112 -> "high"
                else -> "very high"
            }

            else -> null
        }

        val passwordCardColor = when (computed) {
            is UiState.Ok -> when {
                computed.bitsOfEntropy < 56 -> SpecColors.Red
                computed.bitsOfEntropy < 72 -> SpecColors.Yellow
                else -> SpecColors.Green
            }

            else -> MaterialTheme.colorScheme.surfaceVariant
        }

        val saveCurrentPasswordIfEnabled = {
            val currentPassword = (computed as? UiState.Ok)?.password
            if (savePasswordBeforeClear && !currentPassword.isNullOrBlank()) {
                val updated = (listOf(currentPassword) + recentPasswords).take(SettingsStore.MAX_RECENT_PASSWORDS)
                recentPasswords = updated
                settingsScope.launch { SettingsStore.setRecentPasswords(context, updated) }
            }
        }

        val clearAllInputs = {
            // FSD: clear ALL inputs and switch active panel back to Rolls
            rolls = ""
            dirs = ""
            order = ""
            orderKbd = OrderKbd.K1
            activeField = Field.Rolls
            focusManager.clearFocus()
        }
        val applyPendingClearFromHint = { shouldSavePassword: Boolean ->
            if (shouldSavePassword && !pendingClearPassword.isNullOrBlank()) {
                val updated =
                    (listOf(pendingClearPassword!!) + recentPasswords).take(SettingsStore.MAX_RECENT_PASSWORDS)
                recentPasswords = updated
                settingsScope.launch { SettingsStore.setRecentPasswords(context, updated) }
            }
            pendingClearFromHint = false
            pendingClearPassword = null
            pendingClearSaveEnabledDuringOptions = false
            clearAllInputs()
        }
        val cancelPendingClearFromHint = {
            pendingClearFromHint = false
            pendingClearPassword = null
            pendingClearSaveEnabledDuringOptions = false
        }
        val hasAnyDataToClear =
            rolls.isNotEmpty() ||
                dirs.isNotEmpty() ||
                order.isNotEmpty() ||
                ((computed as? UiState.Ok)?.password?.isNotEmpty() == true)
        val hasCopyablePassword = (computed as? UiState.Ok)?.password?.isNotBlank() == true
        val finishWalkthrough = {
            walkthroughStepIndex = null
            if (!hasCompletedWalkthrough) {
                hasCompletedWalkthrough = true
                settingsScope.launch { SettingsStore.setHasCompletedWalkthrough(context, true) }
            }
        }

        ScreenWithFixedKeyboard(
            fallbackKeyboardHeight = startupKeyboardFallback,
            keyboard = { keyboardModifier ->
                when (activeField) {
                    Field.Rolls -> Box(
                        modifier = keyboardModifier
                            .onGloballyPositioned {
                                walkthroughBounds[WalkthroughTarget.Keyboard] = it.boundsInRoot()
                            }
                    ) {
                        RollsKeypad(
                            rolls = rolls,
                            onDigit = { c -> rolls = appendIfFits(rolls, c.toString()) },
                            onBackspace = { if (rolls.isNotEmpty()) rolls = rolls.dropLast(1) },
                            onClear = { rolls = "" },
                            onPaste = {
                                val txt = clipboard.getText()?.text ?: ""
                                val filtered = Validation.filterRollsPaste(txt)
                                rolls = appendIfFits(rolls, filtered)
                            }
                        )
                    }

                    Field.Directions -> Box(
                        modifier = keyboardModifier
                            .onGloballyPositioned {
                                walkthroughBounds[WalkthroughTarget.Keyboard] = it.boundsInRoot()
                            }
                    ) {
                        DirectionsKeypad(
                            dirs = dirs,
                            onDir = { c -> dirs = appendIfFits(dirs, c.toString()) },
                            onBackspace = { if (dirs.isNotEmpty()) dirs = dirs.dropLast(1) },
                            onClear = { dirs = "" },
                            onPaste = {
                                val txt = clipboard.getText()?.text ?: ""
                                val filtered = Validation.filterDirectionsPaste(txt)
                                dirs = appendIfFits(dirs, filtered)
                            }
                        )
                    }

                    Field.Order -> Box(
                        modifier = keyboardModifier
                            .onGloballyPositioned {
                                walkthroughBounds[WalkthroughTarget.Keyboard] = it.boundsInRoot()
                            }
                    ) {
                        OrderKeypad(
                            order = order,
                            parsed = orderParsed,
                            mode = orderKbd,
                            onModeSwitch = {
                                orderKbd = if (orderKbd == OrderKbd.K1) OrderKbd.K2 else OrderKbd.K1
                            },
                            onAppendText = { add -> order = appendIfFits(order, add) },
                            onBackspaceChar = { if (order.isNotEmpty()) order = order.dropLast(1) },
                            onBackspaceToken = {
                                val nums = Validation.parseOrderLoose(order).numbers
                                order = if (nums.isEmpty()) "" else nums.dropLast(1).joinToString("-").let {
                                    if (it.isEmpty()) "" else "$it-"
                                }
                            },
                            onClear = { order = "" },
                            onPaste = {
                                val txt = clipboard.getText()?.text ?: ""
                                val filtered = Validation.filterOrderPaste(txt)
                                order = appendIfFits(order, filtered)
                            }
                        )
                    }
                }
            }
        ) { contentModifier ->
            Column(
                modifier = contentModifier,
                verticalArrangement = Arrangement.Top
            ) {
                // Header row (single; avoids duplicate narrow bars)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .onGloballyPositioned {
                            walkthroughBounds[WalkthroughTarget.Header] = it.boundsInRoot()
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showOptions = true }) {
                            Icon(
                                Icons.Filled.Settings,
                                contentDescription = "Options",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = alphabetSpec.statusCode,
                            modifier = Modifier.clickable { showAlphabetsPanel = true },
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(Modifier.weight(1f))


                    Text(
                        "DiceNDO",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(Modifier.weight(1f))

                    TextButton(onClick = { showHelp = true }) {
                        Text(
                            "\u2370",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(upperPanelsScroll),
                    verticalArrangement = Arrangement.Top
                ) {
                    // ===== Password panel (top) =====
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .onGloballyPositioned {
                                walkthroughBounds[WalkthroughTarget.Password] = it.boundsInRoot()
                            },
                        colors = CardDefaults.cardColors(containerColor = passwordCardColor),
                        border = BorderStroke(3.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            val passwordActionButtonColors = ButtonDefaults.buttonColors(
                                disabledContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                                disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )

                            // FSD: [X] | centered 2-lines | [COPY]
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        val currentPassword = (computed as? UiState.Ok)?.password
                                        val isAtRecentPasswordsLimit =
                                            recentPasswords.size >= SettingsStore.MAX_RECENT_PASSWORDS
                                        if (savePasswordBeforeClear && !currentPassword.isNullOrBlank() && isAtRecentPasswordsLimit) {
                                            showRecentPasswordsLimitWarning = true
                                            return@Button
                                        }
                                        if (!savePasswordBeforeClear && shouldShowSaveHistoryHintDialog) {
                                            pendingClearFromHint = true
                                            pendingClearPassword = currentPassword
                                            pendingClearSaveEnabledDuringOptions = false
                                            showSaveHistoryHintDialog = true
                                            return@Button
                                        }
                                        saveCurrentPasswordIfEnabled()
                                        clearAllInputs()
                                    },
                                    enabled = hasAnyDataToClear,
                                    colors = passwordActionButtonColors
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        if (savePasswordBeforeClear) {
                                            Text("+", style = MaterialTheme.typography.titleLarge)
                                        }
                                        Icon(
                                            imageVector = Icons.Filled.Delete,
                                            contentDescription = "Clear data"
                                        )
                                    }
                                }

                                Spacer(Modifier.weight(1f))

                                if (computed is UiState.Ok) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            "Entropy: ${computed.bitsOfEntropy} bits / $entropyLabel",
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                        Text(
                                            "Length: ${computed.effectiveLen}",
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    }
                                } else {
                                    // FSD: no text at all on startup / when invalid
                                    Spacer(Modifier.height(PASS_INFO_PLACEHOLDER_H))
                                }

                                Spacer(Modifier.weight(1f))

                                Button(
                                    onClick = {
                                        val pass = (computed as? UiState.Ok)?.password ?: return@Button
                                        clipboard.setText(AnnotatedString(pass))
                                    },
                                    enabled = hasCopyablePassword,
                                    colors = passwordActionButtonColors
                                ) { Text("COPY") }
                            }

                            Spacer(Modifier.height(4.dp))

                            val passText = (computed as? UiState.Ok)?.password ?: ""
                            ScrollableMonoLine(
                                value = passText,
                                fontSizeSp = 20,
                                bold = true
                            )
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    // ===== Inputs =====
                    Column(
                        modifier = Modifier.onGloballyPositioned {
                            walkthroughBounds[WalkthroughTarget.Inputs] = it.boundsInRoot()
                        }
                    ) {
                        RollsPanel(
                            value = rolls,
                            isActive = activeField == Field.Rolls,
                            onActivate = { activeField = Field.Rolls; focusManager.clearFocus() }
                        )
                        Spacer(Modifier.height(6.dp))
                        DirectionsPanel(
                            value = dirs,
                            isActive = activeField == Field.Directions,
                            onActivate = { activeField = Field.Directions; focusManager.clearFocus() }
                        )
                        Spacer(Modifier.height(6.dp))
                        OrderPanel(
                            value = order,
                            parsed = orderParsed,
                            isActive = activeField == Field.Order,
                            onActivate = { activeField = Field.Order; focusManager.clearFocus() }
                        )
                    }
                }
            }
        }

        val currentWalkthroughIndex = walkthroughStepIndex
        if (currentWalkthroughIndex != null) {
            WalkthroughOverlay(
                stepIndex = currentWalkthroughIndex,
                targetBounds = walkthroughBounds[WALKTHROUGH_STEPS[currentWalkthroughIndex].target],
                onNext = {
                    if (currentWalkthroughIndex == WALKTHROUGH_STEPS.lastIndex) {
                        finishWalkthrough()
                    } else {
                        walkthroughStepIndex = currentWalkthroughIndex + 1
                    }
                },
                onSkip = finishWalkthrough
            )
        }

        if (showOptions) {
            OptionsDialog(
                recentPasswords = recentPasswords,
                alphabetSpec = alphabetSpec,
                numericNStr = numericNStr,
                themeMode = themeMode,
                savePasswordBeforeClear = savePasswordBeforeClear,
                onOpenAlphabets = {
                    showOptions = false
                    if (pendingClearFromHint) {
                        applyPendingClearFromHint(pendingClearSaveEnabledDuringOptions)
                    } else {
                        showAlphabetsPanel = true
                    }
                },
                onSavePasswordBeforeClearChange = { enabled ->
                    savePasswordBeforeClear = enabled
                    if (pendingClearFromHint && enabled) {
                        pendingClearSaveEnabledDuringOptions = true
                    }
                    settingsScope.launch { SettingsStore.setSavePasswordBeforeClear(context, enabled) }
                },
                onThemeModeChange = { selectedThemeMode ->
                    themeMode = selectedThemeMode
                    settingsScope.launch {
                        SettingsStore.setThemeMode(context, selectedThemeMode)
                        AppCompatDelegate.setDefaultNightMode(selectedThemeMode.toNightMode())
                    }
                },
                recentPasswordsUnlocked = recentPasswordsUnlocked,
                recentPasswordsUnlockError = recentPasswordsUnlockError,
                onToggleRecentPasswordsLock = {
                    if (recentPasswordsUnlocked) {
                        recentPasswordsUnlocked = false
                        recentPasswordsUnlockUntilMs = 0L
                        recentPasswordsUnlockError = null
                        return@OptionsDialog
                    }
                    requestRecentPasswordsUnlock(
                        context = context,
                        onSuccess = {
                            recentPasswordsUnlocked = true
                            recentPasswordsUnlockUntilMs =
                                SystemClock.elapsedRealtime() + RECENT_PASSWORDS_UNLOCK_WINDOW_MS
                            recentPasswordsUnlockError = null
                        },
                        onUnlockedWithoutAuth = {
                            recentPasswordsUnlocked = true
                            recentPasswordsUnlockUntilMs =
                                SystemClock.elapsedRealtime() + RECENT_PASSWORDS_UNLOCK_WINDOW_MS
                            recentPasswordsUnlockError = null
                            if (shouldShowWeakUnlockNotice) {
                                showWeakUnlockNotice = true
                            }
                        },
                        onError = { message ->
                            recentPasswordsUnlocked = false
                            recentPasswordsUnlockUntilMs = 0L
                            recentPasswordsUnlockError = message
                        }
                    )
                },
                onCopyList = {
                    if (recentPasswordsUnlocked && recentPasswords.isNotEmpty()) {
                        clipboard.setText(AnnotatedString(recentPasswords.joinToString("\n")))
                    }
                },
                onClearList = {
                    recentPasswords = emptyList()
                    settingsScope.launch { SettingsStore.setRecentPasswords(context, emptyList()) }
                },
                onDismiss = {
                    showOptions = false
                    if (pendingClearFromHint) {
                        applyPendingClearFromHint(pendingClearSaveEnabledDuringOptions)
                    }
                }
            )
        }

        if (showAlphabetsPanel) {
            AlphabetsDialog(
                selectedId = alphabetId,
                numericNStr = numericNStr,
                onNumericNChange = { newN ->
                    numericNStr = newN
                    settingsScope.launch { SettingsStore.setNumericN(context, newN) }
                },
                onSelect = { id ->
                    alphabetId = id
                    settingsScope.launch { SettingsStore.setAlphabetId(context, id) }
                },
                onDismiss = { showAlphabetsPanel = false }
            )
        }

        if (showHelp) {
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                HelpAssetsDialog(
                    helpWebView = helpWebView,
                    navigationState = helpNavigationState,
                    onClose = { showHelp = false }
                )
            }
        }

        if (showRecentPasswordsLimitWarning) {
            AlertDialog(
                onDismissRequest = { showRecentPasswordsLimitWarning = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showRecentPasswordsLimitWarning = false
                            saveCurrentPasswordIfEnabled()
                            clearAllInputs()
                        }
                    ) { Text("CONTINUE") }
                },
                dismissButton = {
                    TextButton(onClick = { showRecentPasswordsLimitWarning = false }) { Text("CANCEL") }
                },
                title = { Text("Recent passwords limit reached") },
                text = {
                    Text("The recent passwords list already contains ${SettingsStore.MAX_RECENT_PASSWORDS} items. Continuing will replace the oldest entry.")
                }
            )
        }

        if (showSaveHistoryHintDialog) {
            SaveHistoryHintDialog(
                onOk = { dontShowAgain ->
                    if (dontShowAgain) {
                        shouldShowSaveHistoryHintDialog = false
                        settingsScope.launch {
                            SettingsStore.setShowSaveHistoryHintDialog(context, false)
                        }
                    }
                    showSaveHistoryHintDialog = false
                    if (pendingClearFromHint) {
                        applyPendingClearFromHint(false)
                    }
                },
                onOpenOptions = { dontShowAgain ->
                    if (dontShowAgain) {
                        shouldShowSaveHistoryHintDialog = false
                        settingsScope.launch {
                            SettingsStore.setShowSaveHistoryHintDialog(context, false)
                        }
                    }
                    showSaveHistoryHintDialog = false
                    showOptions = true
                },
                onDismiss = {
                    showSaveHistoryHintDialog = false
                    cancelPendingClearFromHint()
                }
            )
        }

        if (showWeakUnlockNotice) {
            WeakUnlockNoticeDialog(
                onOk = { dontShowAgain ->
                    if (dontShowAgain) {
                        shouldShowWeakUnlockNotice = false
                        settingsScope.launch {
                            SettingsStore.setShowWeakUnlockNotice(context, false)
                        }
                    }
                    showWeakUnlockNotice = false
                },
                onDismiss = { showWeakUnlockNotice = false }
            )
        }
    }
}


@Composable
private fun HelpAssetsDialog(
    helpWebView: WebView,
    navigationState: HelpNavigationState,
    onClose: () -> Unit
) {
    var canGoBack by remember { mutableStateOf(navigationState.canGoBack()) }
    val context = LocalContext.current
    val systemDarkTheme = isSystemInDarkTheme()
    val useDarkTheme = when (AppCompatDelegate.getDefaultNightMode()) {
        AppCompatDelegate.MODE_NIGHT_YES -> true
        AppCompatDelegate.MODE_NIGHT_NO -> false
        else -> systemDarkTheme
    }
    BackHandler(enabled = true) {
        val wv = helpWebView
        if (navigationState.navigateBack(wv, context, useDarkTheme)) {
            canGoBack = navigationState.canGoBack()
        } else {
            onClose()
        }
    }

    // Full-screen overlay (not a dialog)
    Surface(
        modifier = Modifier.fillMaxSize(),
        tonalElevation = 2.dp
    ) {
        Column(Modifier
            .fillMaxSize()
            .safeDrawingPadding()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val wv = helpWebView
                        if (navigationState.navigateBack(wv, context, useDarkTheme)) {
                            canGoBack = navigationState.canGoBack()
                        }
                    },
                    enabled = canGoBack
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }

                Text(
                    "Help",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )

                TextButton(onClick = onClose) { Text("Close") }
            }

            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { helpWebView },
                update = { view ->
                    // Update back availability whenever navigation changes.
                    view.webViewClient =
                        createHelpWebViewClient(view, context, useDarkTheme, navigationState) { webView ->
                            canGoBack = navigationState.canGoBack()
                        }
                    canGoBack = navigationState.canGoBack()
                }
            )
        }
    }
}

@Composable
private fun SaveHistoryHintDialog(
    onOk: (Boolean) -> Unit,
    onOpenOptions: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var dontShowAgain by rememberSaveable { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onOk(dontShowAgain) }) {
                Text(SAVE_HISTORY_HINT_OK)
            }
        },
        dismissButton = {
            TextButton(onClick = { onOpenOptions(dontShowAgain) }) {
                Text(SAVE_HISTORY_HINT_OPEN_OPTIONS)
            }
        },
        title = { Text(SAVE_HISTORY_HINT_TITLE) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(SAVE_HISTORY_HINT_MESSAGE)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { dontShowAgain = !dontShowAgain },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = dontShowAgain,
                        onCheckedChange = { checked -> dontShowAgain = checked }
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(SAVE_HISTORY_HINT_DONT_SHOW_AGAIN)
                }
            }
        }
    )
}

@Composable
private fun WeakUnlockNoticeDialog(
    onOk: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var dontShowAgain by rememberSaveable { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onOk(dontShowAgain) }) { Text("OK") }
        },
        title = { Text("Recent passwords unlocked") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Recent passwords were unlocked without biometric/PIN verification. " +
                        "To increase security, enable biometrics or screen lock (PIN/pattern/password) on this device."
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { dontShowAgain = !dontShowAgain },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = dontShowAgain,
                        onCheckedChange = { checked -> dontShowAgain = checked }
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(SAVE_HISTORY_HINT_DONT_SHOW_AGAIN)
                }
            }
        }
    )
}

/* ===== STATE ===== */

private sealed class UiState {
    data class Ok(val password: String, val effectiveLen: Int, val bitsOfEntropy: Int) : UiState()
    data object Empty : UiState()
}

/* ===== SHARED UI ===== */
@Composable
private fun OptionsDialog(
    recentPasswords: List<String>,
    alphabetSpec: AlphabetSpec,
    numericNStr: String,
    themeMode: ThemeMode,
    savePasswordBeforeClear: Boolean,
    onOpenAlphabets: () -> Unit,
    onSavePasswordBeforeClearChange: (Boolean) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    recentPasswordsUnlocked: Boolean,
    recentPasswordsUnlockError: String?,
    onToggleRecentPasswordsLock: () -> Unit,
    onCopyList: () -> Unit,
    onClearList: () -> Unit,
    onDismiss: () -> Unit
) {
    var showClearListConfirm by remember { mutableStateOf(false) }
    val optionsScroll = rememberScrollState()
    val recentPasswordsScroll = rememberScrollState()
    val scrollScope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Options") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(optionsScroll),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Alphabet:", fontWeight = FontWeight.Bold)
                Text(
                    text = if (alphabetSpec.isNumeric) {
                        "${alphabetSpec.shortDescEn} ($numericNStr)"
                    } else {
                        "${alphabetSpec.shortDescEn} (${alphabetSpec.alphabet.length})"
                    }
                )
                Text(
                    text = if (alphabetSpec.isNumeric) {
                        numericAlphabetPreview(numericNStr)
                    } else {
                        alphabetSpec.alphabet
                    },
                    fontFamily = FontFamily.Monospace
                )
                Button(
                    onClick = onOpenAlphabets,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CHANGE")
                }

                HorizontalDivider()

                Text("Password clearing behavior", fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Save password before clearing",
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = savePasswordBeforeClear,
                        onCheckedChange = onSavePasswordBeforeClearChange
                    )
                }

                Text("Saved passwords", fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showClearListConfirm = true },
                        enabled = recentPasswords.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Clear recent passwords"
                        )
                    }
                    Button(
                        onClick = onToggleRecentPasswordsLock,
                        enabled = recentPasswords.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (recentPasswordsUnlocked) {
                                Icons.Filled.LockOpen
                            } else {
                                Icons.Filled.Lock
                            },
                            contentDescription = if (recentPasswordsUnlocked) {
                                "Recent passwords unlocked"
                            } else {
                                "Recent passwords locked"
                            }
                        )
                    }
                    Button(
                        onClick = onCopyList,
                        enabled = recentPasswords.isNotEmpty() && recentPasswordsUnlocked,
                        modifier = Modifier.weight(1f)
                    ) { Text("COPY") }
                }
                if (recentPasswords.isNotEmpty() && !recentPasswordsUnlocked) {
                    Text("Recent passwords are locked. Use $LOCK_CLOSED_SYMBOL to unlock.")
                }
                if (!recentPasswordsUnlockError.isNullOrBlank()) {
                    Text(recentPasswordsUnlockError, color = MaterialTheme.colorScheme.error)
                }

                if (recentPasswords.isEmpty()) {
                    Text("No recent passwords.")
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(recentPasswordsScroll),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            recentPasswords.forEachIndexed { index, value ->
                                Text(
                                    text = if (recentPasswordsUnlocked) {
                                        "${index + 1}. $value"
                                    } else {
                                        "${index + 1}. ********"
                                    },
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(Modifier.width(6.dp))
                        Column {
                            IconButton(
                                onClick = {
                                    scrollScope.launch {
                                        val target = (recentPasswordsScroll.value - 120).coerceAtLeast(0)
                                        recentPasswordsScroll.animateScrollTo(target)
                                    }
                                },
                                enabled = recentPasswordsScroll.canScrollBackward
                            ) {
                                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Scroll up")
                            }
                            IconButton(
                                onClick = {
                                    scrollScope.launch {
                                        val target = (recentPasswordsScroll.value + 120)
                                            .coerceAtMost(recentPasswordsScroll.maxValue)
                                        recentPasswordsScroll.animateScrollTo(target)
                                    }
                                },
                                enabled = recentPasswordsScroll.canScrollForward
                            ) {
                                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Scroll down")
                            }
                        }
                    }
                }

                HorizontalDivider()

                Text("Color theme", fontWeight = FontWeight.Bold)
                ThemeMode.entries.forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onThemeModeChange(option) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = themeMode == option,
                            onClick = { onThemeModeChange(option) }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = when (option) {
                                ThemeMode.Light -> "Light"
                                ThemeMode.Dark -> "Dark"
                                ThemeMode.System -> "Use system setting"
                            }
                        )
                    }
                }
            }
        }
    )

    if (showClearListConfirm) {
        AlertDialog(
            onDismissRequest = { showClearListConfirm = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearList()
                        showClearListConfirm = false
                    }
                ) { Text("YES") }
            },
            dismissButton = {
                TextButton(onClick = { showClearListConfirm = false }) { Text("CANCEL") }
            },
            title = { Text("Clear list?") },
            text = { Text("Are you sure you want to clear recent passwords?") }
        )
    }
}

private fun requestRecentPasswordsUnlock(
    context: Context,
    onSuccess: () -> Unit,
    onUnlockedWithoutAuth: () -> Unit,
    onError: (String) -> Unit
) {
    val activity = context.findFragmentActivity()
    if (activity == null) {
        onUnlockedWithoutAuth()
        return
    }

    val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
        BiometricManager.Authenticators.DEVICE_CREDENTIAL
    val biometricManager = BiometricManager.from(context)
    when (biometricManager.canAuthenticate(authenticators)) {
        BiometricManager.BIOMETRIC_SUCCESS -> Unit
        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
            onUnlockedWithoutAuth()
            return
        }
        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE,
        BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE,
        BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED,
        BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED -> {
            onUnlockedWithoutAuth()
            return
        }
        else -> {
            onUnlockedWithoutAuth()
            return
        }
    }

    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Unlock recent passwords")
        .setSubtitle("Use biometrics or device PIN/pattern/password")
        .setAllowedAuthenticators(authenticators)
        .build()

    val prompt = BiometricPrompt(
        activity,
        ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (errorCode == BiometricPrompt.ERROR_USER_CANCELED ||
                    errorCode == BiometricPrompt.ERROR_CANCELED ||
                    errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON
                ) {
                    onError("Unlock canceled.")
                    return
                }
                onError(errString.toString())
            }
        }
    )
    prompt.authenticate(promptInfo)
}

private tailrec fun Context.findFragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findFragmentActivity()
    else -> null
}

@Composable
private fun AlphabetsDialog(
    selectedId: Int,
    numericNStr: String,
    onNumericNChange: (String) -> Unit,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var infoId by remember { mutableStateOf<Int?>(null) }
    val specToShow = remember(infoId) { infoId?.let { Alphabets.byId(it) } }
    val scroll = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Alphabets") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Alphabets.ALL.forEach { spec ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(spec.id) }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (spec.id == selectedId),
                            onClick = { onSelect(spec.id) }
                        )

                        Spacer(Modifier.width(8.dp))

                        Text(
                            text = if (spec.isNumeric) "${spec.shortDescEn} ($numericNStr)" else "${spec.shortDescEn} (${spec.alphabet.length})",
                            modifier = Modifier.weight(1f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(Modifier.width(8.dp))

                        IconButton(onClick = { infoId = spec.id }) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = "Alphabet info"
                            )
                        }
                    }
                }

                if (selectedId == 7) {
                    Spacer(Modifier.height(6.dp))
                    Text("n (range 0..n-1)", fontWeight = FontWeight.Bold)

                    val curN = numericNStr.toIntOrNull()?.coerceIn(2, 256) ?: 100
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(
                            onClick = {
                                val next = (curN - 1).coerceAtLeast(2)
                                onNumericNChange(next.toString())
                            },
                            enabled = curN > 2
                        ) { Text("-") }

                        Text(
                            text = curN.toString(),
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )

                        TextButton(
                            onClick = {
                                val next = (curN + 1).coerceAtMost(256)
                                onNumericNChange(next.toString())
                            },
                            enabled = curN < 256
                        ) { Text("+") }
                    }

                    Spacer(Modifier.height(2.dp))
                    Text("Allowed range: 2..256")
                }
            }
        }
    )

    if (specToShow != null) {
        AlertDialog(
            onDismissRequest = { infoId = null },
            confirmButton = { TextButton(onClick = { infoId = null }) { Text("Close") } },
            title = { Text("Alphabet preview") },
            text = {
                Column(modifier = Modifier.verticalScroll(scroll)) {
                    Text(
                        text = specToShow.fullDescEn,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (specToShow.isNumeric) numericAlphabetPreview(numericNStr) else specToShow.alphabet,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        )
    }
}

private fun numericAlphabetPreview(nStr: String): String {
    val nInt = nStr.toIntOrNull()?.coerceIn(2, 256) ?: 100
    val n = java.math.BigInteger.valueOf(nInt.toLong())
    if (n <= java.math.BigInteger.ONE) return "n = $n (range: 0..0)"
    val maxPreview = 50
    val previewCount = try {
        n.min(java.math.BigInteger.valueOf(maxPreview.toLong())).toInt()
    } catch (_: Exception) {
        maxPreview
    }
    val sb = StringBuilder()
    sb.append("List of random numbers\n")
    sb.append("range: 0..").append(n.subtract(java.math.BigInteger.ONE)).append("\n\n")
    sb.append("preview: ")
    for (i in 0 until previewCount) {
        if (i > 0) sb.append("-")
        sb.append(i)
    }
    if (n > java.math.BigInteger.valueOf(maxPreview.toLong())) sb.append("-...")
    return sb.toString()
}
